/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useLayoutEffect, useState, useRef } from "react";
import fileIcon from "./file.png";
import folderIcon from "./folder.png";
import "./App.css";
import ReactPlayer from "react-player";
import _ from "lodash";
import Duration from "./Duration";
import { plainCueText } from "./assText";
import {
  buildAssLayer,
  buildSavedMatcher,
  highlightSaved,
  hoverSavedHandlers,
  wordSelectHandlers,
  swipeSelectHandlers,
  recentWordSelect,
  SUB_FONT_CHOICES,
  setSubFontFamily
} from "./assLayer";
import { getWords, WORDS_EVENT, WORDS_KEY } from "./translateLib";
import TranslatePopup from "./translatePopup";
import { isTV, isTouch } from "./device";
import { Link, useHistory } from "react-router-dom";

// Xoay màn hình theo toàn màn hình (điện thoại / máy tính bảng): vào full -> khoá ngang, thoát -> khoá dọc rồi trả lại tự xoay.
// Chỉ chạy ở trình duyệt có screen.orientation.lock (Chrome / Firefox Android); iPhone không hỗ trợ nên bỏ qua êm.
const orient = () => (typeof window !== "undefined" && window.screen && window.screen.orientation) || null;
const lockOrient = (type) => {
  const o = orient();
  if (!o || !o.lock) return Promise.resolve();
  try {
    return o.lock(type).catch(() => {});
  } catch (e) {
    return Promise.resolve();
  }
};
const unlockOrient = () => {
  const o = orient();
  try {
    if (o && o.unlock) o.unlock();
  } catch (e) {}
};

const Home = (props) => {
  const playerRef = useRef(null);
  const currentRef = useRef(null);
  let history = useHistory();
  let hostname = window.location.hostname;
  let rootPath = decodeURIComponent(window.location.pathname);
  const fullPathRoot = _.filter(rootPath.split("/"), (root) => !!root);
  let root = _.first(fullPathRoot) || "";
  let fileNameUrl = _.last(fullPathRoot) || "";
  let pathName = _.drop(_.clone(fullPathRoot)).join("/");
  let backRootPath = _.dropRight(_.clone(fullPathRoot)).join("/");
  let pathViewFile = fullPathRoot.join("/");
  const fName = props?.location?.state?.folder;

  const queryParams = new URLSearchParams(window.location.search);
  const type = queryParams.get("type");
  const publicURL = `http://${hostname}:8081/public/`;
  const subtitlesURL = `http://${hostname}:8081/subtitles/`;
  const subtitlesStyleURL = `http://${hostname}:8081/subtitles-style/`;
  const trasksURL = `http://${hostname}:8081/trasks/`;
  const pickURL = `http://${hostname}:8081/pick/`;
  const audiosURL = `http://${hostname}:8081/audios/`;
  const mediaPrepareURL = `http://${hostname}:8081/media-prepare/`;
  const mediaURL = `http://${hostname}:8081/media-file/`;
  const sample_video = document.getElementById("sample_video");
  const video = document.getElementsByTagName("video")[0];
  const textTracks = _.get(video, "textTracks", null);
  const stateInit = {
    pip: false,
    playing: true,
    controls: false,
    light: false,
    volume: 1,
    muted: false,
    played: 0,
    loaded: 0,
    duration: 0,
    playbackRate: (() => {
      try {
        const r = parseFloat(localStorage.getItem("playbackRate"));
        return r >= 0.25 && r <= 3 ? r : 1.0;
      } catch (e) {
        return 1.0;
      }
    })(),
    loop: false
  };

  const [folders, setFolders] = useState([]);
  const [filesOfParent, setFilesOfParent] = useState([]);
  const [subtitles, setSubtitles] = useState(null);
  const [trWord, setTrWord] = useState(null); // { text, anchor, id } từ / đoạn sub đang dịch
  // Mở cửa sổ dịch cho một từ / đoạn (bấm chọn, rê chuột lên từ đã lưu, Ctrl+C+C)
  const openTranslate = (text, anchor, meta) => text && setTrWord({ text, anchor, id: Date.now(), hoverId: meta && meta.hoverId });
  // Từ đã lưu -> tô sáng trong sub; cập nhật ngay khi lưu / xoá từ (cả ở tab khác)
  const [savedSrcs, setSavedSrcs] = useState(() => getWords().map((w) => w.src));
  const savedMatcher = React.useMemo(() => buildSavedMatcher(savedSrcs), [savedSrcs]);
  useEffect(() => {
    const refresh = () => setSavedSrcs(getWords().map((w) => w.src));
    const onStorage = (e) => {
      if (!e.key || e.key === WORDS_KEY) refresh();
    };
    window.addEventListener(WORDS_EVENT, refresh);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(WORDS_EVENT, refresh);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  // Nhấn Ctrl+C (Cmd+C trên Mac) hai lần trong 600ms khi đang bôi đen chữ -> dịch đoạn đang chọn (giống chế độ Ctrl+C+C của extension)
  useEffect(() => {
    let last = 0;
    const onKey = (e) => {
      if (e.repeat || e.altKey || e.shiftKey || !(e.ctrlKey || e.metaKey) || e.code !== "KeyC") return;
      const tag = e.target && e.target.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const now = Date.now();
      if (now - last > 600) {
        last = now;
        return;
      }
      last = 0;
      const sel = window.getSelection && window.getSelection();
      const text = sel && sel.rangeCount ? sel.toString().trim() : "";
      if (!text) return;
      const r = sel.getRangeAt(0).getBoundingClientRect();
      setTrWord({ text: text.slice(0, 1000), anchor: { x: r.left, y: r.bottom, top: r.top }, id: Date.now() });
    };
    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  }, []);
  const [fileName, setFileName] = useState("");
  const [nextFile, setNextFile] = useState("");
  const [previousFile, setPreviousFile] = useState("");
  const [hide, setHide] = useState(false);
  const [boxTracks, setBoxTracks] = useState(false);
  const [state, setState] = useState(stateInit);
  const [isFullSreen, setIsFullSreen] = useState(false);
  const [indexFile, setIndexFile] = useState(null);
  const [indexSub, setIndexSub] = useState(0);
  const [subDelay, setSubDelay] = useState(0); // độ trễ phụ đề (giây). Dương = phụ đề hiện trễ hơn
  // TV: điều khiển kiểu remote (di chuyển chuột để chọn). PC/khác: dùng chuột bình thường.
  const isMouse = !isTV();
  const touch = isMouse && isTouch(); // điện thoại / máy tính bảng: nút to hơn, chạm hai bên video để tua
  // Kích thước cửa sổ: màn hình dọc hoặc hẹp thì xếp video ở trên, khung phụ đề ở dưới
  const [view, setView] = useState({ w: window.innerWidth, h: window.innerHeight });
  useEffect(() => {
    const onResize = () => setView({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
    };
  }, []);
  // Cảm ứng + đang full screen: khung sub nằm bên cạnh video (xếp ngang), có nút đóng / mở
  const fsSide = touch && isFullSreen;
  const [sideOpen, setSideOpen] = useState(() => {
    try {
      return localStorage.getItem("fsSideOpen") === "1";
    } catch (e) {
      return false;
    }
  });
  const toggleSide = () => {
    setSideOpen((v) => {
      try {
        localStorage.setItem("fsSideOpen", v ? "0" : "1");
      } catch (e) {}
      return !v;
    });
  };
  const stacked = isMouse && !fsSide && (view.h > view.w || view.w < 640);
  // Chế độ chỉ nghe tiếng: ẩn hình (video vẫn chạy), khung phụ đề chiếm chỗ của video, bấm vào chữ để tô đen / dịch
  const [audioOnly, setAudioOnly] = useState(false);
  const [subFont, setSubFont] = useState(() => {
    try {
      return localStorage.getItem("subFontChoice") || "";
    } catch (e) {
      return "";
    }
  });
  setSubFontFamily(subFont); // áp dụng ngay cho lần vẽ sub kế tiếp
  useEffect(() => {
    try {
      localStorage.setItem("subFontChoice", subFont);
    } catch (e) {}
  }, [subFont]);
  const [cuePanelHidden, setCuePanelHidden] = useState(false); // ẩn khung phụ đề bên phải (danh sách câu)
  const layoutStacked = stacked || audioOnly; // chỉ nghe thì luôn xếp dọc: thanh điều khiển gọn ở trên, danh sách sub phía dưới

  // Điện thoại: nhấn giữ + kéo cột chọn để bôi đen KHÔNG phát mouseup nên không dịch được như trên PC.
  // Nghe selectionchange: vừa chọn vào chữ sub thì tạm dừng (sub đổi câu sẽ mất vùng chọn), dừng tay 0.7s thì dịch đoạn đang chọn.
  const trWordRef = useRef(null);
  trWordRef.current = trWord;
  const audioOnlyRef = useRef(false);
  audioOnlyRef.current = audioOnly;
  useEffect(() => {
    if (!touch) return;
    let timer;
    // Vùng chọn hiện tại nếu nằm trong chữ sub (lớp sub trên video, hoặc khung danh sách khi đang chỉ nghe), ngược lại null
    const subSelection = () => {
      const sel = window.getSelection && window.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
      const node = sel.anchorNode;
      const el = node && (node.nodeType === 1 ? node : node.parentElement);
      const seg = el && el.closest ? el.closest("[data-sub-seg]") : null;
      if (!seg) return null;
      if (seg.closest("#cue_panel") && !audioOnlyRef.current) return null; // khung danh sách chỉ dịch ở chế độ chỉ nghe (giống PC)
      const text = sel.toString().replace(/\s+/g, " ").trim();
      return text ? { sel, text: text.slice(0, 1000) } : null;
    };
    const onSelectionChange = () => {
      clearTimeout(timer);
      if (recentWordSelect()) return; // vừa bấm 1 từ: đã tự dịch rồi
      const first = subSelection();
      if (!first) return;
      if (playingRef.current) setStateElmRef.current({ playing: false }); // chọn chữ thì tạm dừng cho kịp bôi đen / đọc nghĩa
      timer = setTimeout(() => {
        const cur = subSelection();
        if (!cur || recentWordSelect()) return;
        if (trWordRef.current && trWordRef.current.text === cur.text) return; // đoạn này đang được dịch
        const r = cur.sel.getRangeAt(0).getBoundingClientRect();
        openTranslate(cur.text, { x: r.left, y: r.bottom, top: r.top });
      }, 700);
    };
    document.addEventListener("selectionchange", onSelectionChange);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("selectionchange", onSelectionChange);
    };
  }, [touch]);
  // Độ rộng thật của khung chứa video + phụ đề (đo lại khi xoay màn hình / đổi kích thước)
  const stackRef = useRef(null);
  const [stackW, setStackW] = useState(0);
  useEffect(() => {
    const el = stackRef.current;
    if (!el) return;
    const w = el.clientWidth;
    if (w && w !== stackW) setStackW(w);
  }, [view.w, view.h, stacked, type, pathViewFile]);
  const bodyW = stackW || Math.min(view.w * 0.96, 1800);
  const [audioList, setAudioList] = useState([]);
  const [boxAudio, setBoxAudio] = useState(false);
  const [boxFont, setBoxFont] = useState(false); // menu chọn font phụ đề
  const [indexFont, setIndexFont] = useState(0); // mục đang chọn (remote) trong menu font
  const [indexSpeed, setIndexSpeed] = useState(0); // mục đang chọn (remote) trong menu tốc độ
  const [boxSpeed, setBoxSpeed] = useState(false); // menu tốc độ phát
  const [boxDelay, setBoxDelay] = useState(false); // menu chỉnh độ trễ phụ đề
  const [indexDelay, setIndexDelay] = useState(0);
  const [indexAudio, setIndexAudio] = useState(0);
  const [toast, setToast] = useState("");
  const toastRef = useRef(null);
  const [mediaSrc, setMediaSrc] = useState(null); // null = file gốc; có giá trị = file đã remux (video + audio đã chọn)
  const resumeAtRef = useRef(null); // vị trí cần tua tới sau khi đổi nguồn video
  const audioTokenRef = useRef(0);
  const prepTimerRef = useRef(null); // đếm giây khi đang tách audio // huỷ polling cũ khi chọn audio khác / đổi file
  const audioTargetRef = useRef(null); // audio đang được chọn (kể cả khi đang tách)
  // Trạng thái popup mới nhất (handler back đọc từ đây, tránh closure cũ)
  const swipeCue = swipeSelectHandlers({ onWord: openTranslate });
  const popupRef = useRef({ trWord: false, boxTracks: false, boxAudio: false, boxSpeed: false, boxDelay: false, boxFont: false });
  popupRef.current = { trWord: !!trWord, boxTracks, boxAudio, boxSpeed, boxDelay, boxFont };

  if (!_.isEmpty(textTracks) && !_.isEmpty(subtitles)) {
    const subtitle = subtitles.find((s) => s.default);
    for (const element of textTracks) {
      element.mode = "hidden"; // phụ đề tự vẽ bằng overlay (nền đen đặc)
    }
  }

  // Đóng popup đang mở (ưu tiên trên cùng). Trả về true nếu đã đóng được popup.
  const closePopupIfOpen = () => {
    const open = popupRef.current;
    if (open.trWord) {
      setTrWord(null);
      popupRef.current = { ...open, trWord: false };
    } else if (open.boxDelay) {
      setBoxDelay(false);
      setBoxFont(false);
      popupRef.current = { ...open, boxDelay: false };
    } else if (open.boxFont) {
      setBoxFont(false);
      popupRef.current = { ...open, boxFont: false };
    } else if (open.boxSpeed) {
      setBoxSpeed(false);
      setBoxFont(false);
      popupRef.current = { ...open, boxSpeed: false };
    } else if (open.boxAudio) {
      setBoxAudio(false);
      setBoxFont(false);
      popupRef.current = { ...open, boxAudio: false };
    } else if (open.boxTracks) {
      setBoxTracks(false);
      setBoxFont(false);
      popupRef.current = { ...open, boxTracks: false };
    } else {
      return false;
    }
    if (!isMouse) setIndexFile(0);
    return true;
  };

  const onBackButtonEvent = (e) => {
    if (closePopupIfOpen()) {
      // Có popup: chỉ đóng popup, giữ trang xem và "bẫy" lần back tiếp theo
      window.history.pushState(null, null, window.location.pathname + window.location.search);
      return;
    }
    window.history.pushState(null, null, window.location.pathname + window.location.search);
    history.replace(`/${backRootPath}`, { folder: _.last(fullPathRoot) });
  };

  useEffect(() => {
    if (type === "file") onFullSreenEvent();
  }, []);

  useLayoutEffect(() => {
    setSubtitles(null);
    setSubDelay(0);
    setStateElm({ played: 0, playing: true });
    setBoxTracks(false);
    setBoxFont(false);
    setBoxAudio(false);
    setBoxFont(false);
    setBoxDelay(false);
    setBoxFont(false);
    setBoxSpeed(false);
    setBoxFont(false);
    stopExternalAudio();
    setAudioList([]);
    if (type !== "file") {
      fetch(publicURL + fullPathRoot.join("/"))
        .then((response) => response.json())
        .then((data) => setFolders(data));
    } else {
      getSubtitles();
      getAudioList();
      fetch(publicURL + backRootPath)
        .then((response) => response.json())
        .then((data) => setFilesOfParent(data.filter((d) => d.type === "file")));
    }
    window.addEventListener("fullscreenchange", onFullSreenEvent);
    window.history.pushState(null, null, window.location.pathname + window.location.search);
    window.addEventListener("popstate", onBackButtonEvent);
    return () => {
      window.removeEventListener("popstate", onBackButtonEvent);
      window.removeEventListener("fullscreenchange", onFullSreenEvent);
    };
  }, [rootPath]);

  useEffect(() => {
    const index = _.findIndex(filesOfParent, (f) => f.name === fileNameUrl);
    setFileName((filesOfParent[index] || {}).name);
    setNextFile((filesOfParent[index + 1] || {}).name);
    setPreviousFile((filesOfParent[index - 1] || {}).name);
  }, [filesOfParent]);

  useEffect(() => {
    if (!_.isEmpty(folders)) {
      setIndexFile(fName ? _.findIndex(folders, (f) => f.name === fName) : 0);
    }
  }, [folders]);

  useEffect(() => {
    const files = document.getElementsByClassName("f-active");
    if (files && !_.isEmpty(files)) {
      for (const element of files) {
        element.classList.remove("f-active");
      }
    }
    const nextFile = document.getElementById(`file_${indexFile}`);
    if (nextFile) {
      nextFile.classList.add("f-active");
      nextFile.scrollIntoView();
    }
    const playFile = document.getElementById(`play_${indexFile}`);
    if (playFile) {
      playFile.classList.add("f-active");
    }
  }, [indexFile, state]);

  useEffect(() => {
    const files = document.getElementsByClassName("s-active");
    if (files && !_.isEmpty(files)) {
      for (const element of files) {
        element.classList.remove("s-active");
      }
    }
    // indexSub: 0..n = cột Sub 1 (Off + n sub), từ n+1 trở đi = cột Sub 2 (Off + các sub còn lại)
    const subCount = subtitles ? subtitles.length : 0;
    const subFile = document.getElementById(indexSub <= subCount ? `sub_${indexSub}` : `sub2_${indexSub - subCount - 1}`);
    if (subFile) {
      subFile.classList.add("s-active");
    }
  }, [indexSub, subtitles]);

  useEffect(() => {
    const items = document.getElementsByClassName("a-active");
    if (items && !_.isEmpty(items)) {
      for (const element of Array.from(items)) {
        element.classList.remove("a-active");
      }
    }
    const audioItem = document.getElementById(`aud_${indexAudio}`);
    if (audioItem) {
      audioItem.classList.add("a-active");
    }
  }, [indexAudio, boxAudio, audioList]);

  // ---------- Chọn audio (server tách audio track -> phát bằng <audio> đồng bộ với video) ----------
  const encodedPathViewFile = () => pathViewFile.split("/").map(encodeURIComponent).join("/");

  const showToast = (text, ms = 2000) => {
    setToast(text);
    clearTimeout(toastRef.current);
    if (ms > 0) toastRef.current = setTimeout(() => setToast(""), ms);
  };

  const getAudioList = () => {
    audioTargetRef.current = null;
    fetch(audiosURL + encodedPathViewFile())
      .then((response) => response.json())
      .then((data) => {
        if (!Array.isArray(data)) return;
        const defaultIndex = Math.max(
          _.findIndex(data, (a) => a.default),
          0
        );
        setAudioList(data.map((a, i) => ({ label: a.label, isDefault: i === defaultIndex, enabled: i === defaultIndex })));
      })
      .catch(() => setAudioList([]));
  };

  const markAudioEnabled = (index) => {
    setAudioList((list) => list.map((a, i) => ({ ...a, enabled: i === index })));
    setIndexAudio(index);
  };

  const stopExternalAudio = () => {
    audioTokenRef.current = 0;
    resumeAtRef.current = null;
    setMediaSrc(null);
  };

  const clearPrepTimer = () => {
    clearInterval(prepTimerRef.current);
    prepTimerRef.current = null;
  };

  const changeAudio = (index) => {
    const item = audioList[index];
    if (!item) return;
    clearPrepTimer();
    audioTargetRef.current = index;
    const token = Date.now();
    audioTokenRef.current = token;

    if (item.isDefault) {
      // Audio gốc: quay về file gốc, giữ nguyên vị trí phát
      if (mediaSrc) {
        resumeAtRef.current = playerRef.current ? playerRef.current.getCurrentTime() || 0 : 0;
        setMediaSrc(null);
      }
      markAudioEnabled(index);
      showToast(`Audio: ${item.label}`);
      return;
    }

    const startedAt = Date.now();
    const showWaiting = () => showToast(`Đang chuẩn bị audio: ${item.label}... ${Math.round((Date.now() - startedAt) / 1000)}s`, 0);
    showWaiting();
    prepTimerRef.current = setInterval(() => {
      if (audioTokenRef.current !== token) return clearPrepTimer();
      showWaiting();
    }, 1000);

    const poll = () => {
      fetch(mediaPrepareURL + encodedPathViewFile() + `?track=${index}`)
        .then((response) => response.json())
        .then((data) => {
          if (audioTokenRef.current !== token) return; // đã chọn audio khác
          if (data.ready) {
            clearPrepTimer();
            resumeAtRef.current = playerRef.current ? playerRef.current.getCurrentTime() || 0 : 0;
            setMediaSrc(mediaURL + encodedPathViewFile() + `?track=${index}`);
            markAudioEnabled(index);
            showToast(`Audio: ${item.label}`);
          } else if (data.waiting) {
            setTimeout(poll, 1500);
          } else {
            clearPrepTimer();
            audioTargetRef.current = null;
            showToast("Không tách được audio này", 3000);
          }
        })
        .catch(() => {
          if (audioTokenRef.current !== token) return;
          clearPrepTimer();
          audioTargetRef.current = null;
          showToast("Không kết nối được server audio", 3000);
        });
    };
    poll();
  };

  const cycleAudio = () => {
    if (audioList.length < 2) {
      showToast("File này chỉ có 1 audio");
      return;
    }
    let current = audioTargetRef.current;
    if (current === null || current === undefined)
      current = Math.max(
        _.findIndex(audioList, (a) => a.enabled),
        0
      );
    changeAudio((current + 1) % audioList.length);
  };

  const boxFontHandle = () => {
    if (!boxFont) {
      setIndexFont(
        Math.max(
          0,
          SUB_FONT_CHOICES.findIndex((f) => f.value === subFont)
        )
      );
      setBoxTracks(false);
      setBoxFont(false);
      setBoxDelay(false);
      setBoxFont(false);
      setBoxSpeed(false);
      setBoxFont(false);
      setBoxAudio(false);
      setBoxFont(false);
    }
    setBoxFont(!boxFont);
  };
  const boxAudioHandle = () => {
    if (_.isEmpty(audioList) && !isMouse) return; // PC/điện thoại: popup còn có nút tắt âm nên vẫn mở
    if (!boxAudio) {
      setIndexAudio(
        Math.max(
          _.findIndex(audioList, (a) => a.enabled),
          0
        )
      );
      setBoxTracks(false);
      setBoxFont(false);
      setBoxDelay(false);
      setBoxFont(false);
      setBoxSpeed(false);
      setBoxFont(false);
    }
    setBoxAudio(!boxAudio);
  };

  const changeSubtitle = (language, noSetSub) => {
    if (textTracks && textTracks.length > 0) {
      for (const element of textTracks) {
        element.mode = "hidden";
      }
    }
    const newSybtitle = _.clone(subtitles);
    newSybtitle.forEach((sub) => {
      sub.default = sub.language === language;
    });
    if (!noSetSub) setSubtitles(newSybtitle);
  };

  useEffect(() => {
    const items = document.getElementsByClassName("d-active");
    if (items && !_.isEmpty(items)) {
      for (const element of Array.from(items)) {
        element.classList.remove("d-active");
      }
    }
    const delayItem = document.getElementById(`del_${indexDelay}`);
    if (delayItem) {
      delayItem.classList.add("d-active");
    }
  }, [indexDelay, boxDelay]);

  // ---------- Chỉnh độ trễ phụ đề ----------
  const SUB_DELAY_STEP = 0.1; // giây
  const SUB_DELAY_STEP_LONG = 1; // giây, giữ Shift

  const formatDelay = (d) => `${d > 0 ? "+" : ""}${d.toFixed(1)}s`;

  // Dịch thời gian của tất cả cue (tính từ thời điểm gốc nên không bị cộng dồn sai số)
  const applySubDelay = (delay) => {
    const videoEl = document.getElementsByTagName("video")[0];
    if (!videoEl || !videoEl.textTracks) return;
    for (const track of Array.from(videoEl.textTracks)) {
      if (!track.cues) continue;
      for (const cue of Array.from(track.cues)) {
        const applied = cue._subDelay || 0;
        if (applied === delay) continue;
        if (cue._origStart === undefined) {
          cue._origStart = cue.startTime;
          cue._origEnd = cue.endTime;
        }
        cue.startTime = cue._origStart + delay;
        cue.endTime = cue._origEnd + delay;
        cue._subDelay = delay;
      }
    }
  };

  // ---------- Danh sách phụ đề bên cạnh video (PC) ----------
  const [cueList, setCueList] = useState([]); // [{ start, end, text }]
  const [cueIndex, setCueIndex] = useState(-1); // cue đang được phát (-1: không có)
  const [gap, setGap] = useState(null); // khoảng trống giữa hai sub: { next: idx sub kế tiếp, p: tỉ lệ đã trôi 0..1 }
  const [loopIndex, setLoopIndex] = useState(-1); // cue đang bật lặp lại (-1: tắt)
  const loopWaitRef = useRef(false); // khoá ngắn sau mỗi lần tua lặp
  const loopTimerRef = useRef(null);
  const loopSinceRef = useRef(0);
  const setStateElmRef = useRef(null);
  const lastCueRef = useRef(-2);
  const userScrollRef = useRef(0);
  const activeSubLang = _.get(
    _.find(subtitles || [], (sub) => sub.default),
    "language",
    null
  );

  const cleanCueText = (text) => plainCueText(text);

  // ---------- Phụ đề tự vẽ theo thiết lập trong sub (ASS: vị trí, cỡ chữ, màu...), nền đen đặc ----------
  const [liveCues, setLiveCues] = useState([]); // cue đang hiển thị: [{ key, id, text }]
  const [assMeta, setAssMeta] = useState(null); // { playResX, playResY, styles } của sub đang chọn
  useEffect(() => {
    setAssMeta(null);
    if (type !== "file" || !activeSubLang || !pathViewFile) return;
    let cancelled = false;
    fetch(subtitlesStyleURL + pathViewFile + `?language=${activeSubLang}`)
      .then((r) => r.json())
      .then((d) => !cancelled && setAssMeta(d || {}))
      .catch(() => !cancelled && setAssMeta({}));
    return () => {
      cancelled = true;
    };
  }, [activeSubLang, pathViewFile]);

  useEffect(() => {
    setLiveCues([]);
    if (type !== "file" || !activeSubLang) return;
    let timer;
    let tries = 0;
    let track = null;
    const onCueChange = () => {
      const cues = track && track.activeCues ? Array.from(track.activeCues) : [];
      const next = cues.map((c) => ({ key: `${c.startTime}-${c.endTime}`, id: c.id, text: c.text || "" }));
      setLiveCues((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next));
    };
    const attach = () => {
      const videoEl = document.getElementsByTagName("video")[0];
      track = videoEl && videoEl.textTracks ? Array.from(videoEl.textTracks).find((t) => t.language === activeSubLang) : null;
      if (track) {
        track.mode = "hidden";
        track.addEventListener("cuechange", onCueChange);
        onCueChange();
      } else if (tries++ < 120) {
        timer = setTimeout(attach, 500);
      }
    };
    attach();
    return () => {
      clearTimeout(timer);
      if (track) track.removeEventListener("cuechange", onCueChange);
    };
  }, [activeSubLang, pathViewFile]);

  // ---------- Sub 2 (hiện nhỏ, không đậm, nằm dưới sub 1) ----------
  const [secondLang, setSecondLang] = useState(() => {
    try {
      return localStorage.getItem("secondSubLang") || null;
    } catch (e) {
      return null;
    }
  });
  const chooseSecondSub = (language) => {
    setSecondLang(language);
    try {
      if (language) localStorage.setItem("secondSubLang", language);
      else localStorage.removeItem("secondSubLang");
    } catch (e) {}
  };
  const secLang = secondLang && secondLang !== activeSubLang && (subtitles || []).some((sub) => sub.language === secondLang) ? secondLang : null;
  const [liveCues2, setLiveCues2] = useState([]);
  useEffect(() => {
    setLiveCues2([]);
    if (type !== "file" || !secLang) return;
    let timer;
    let tries = 0;
    let track = null;
    const onCueChange = () => {
      const cues = track && track.activeCues ? Array.from(track.activeCues) : [];
      const next = cues.map((c) => ({ key: `${c.startTime}-${c.endTime}`, text: c.text || "" }));
      setLiveCues2((prev) => (JSON.stringify(prev) === JSON.stringify(next) ? prev : next));
    };
    const attach = () => {
      const videoEl = document.getElementsByTagName("video")[0];
      track = videoEl && videoEl.textTracks ? Array.from(videoEl.textTracks).find((t) => t.language === secLang) : null;
      if (track) {
        track.mode = "hidden"; // hidden vẫn tải cue, chỉ không để trình duyệt tự vẽ
        track.addEventListener("cuechange", onCueChange);
        onCueChange();
      } else if (tries++ < 120) {
        timer = setTimeout(attach, 500);
      }
    };
    attach();
    return () => {
      clearTimeout(timer);
      if (track) track.removeEventListener("cuechange", onCueChange);
    };
  }, [secLang, activeSubLang, pathViewFile]);

  const formatClock = (sec) => {
    const total = Math.max(Math.floor(sec), 0);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const ss = String(total % 60).padStart(2, "0");
    return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
  };

  // Đổi ngôn ngữ phụ đề / đổi file -> xoá danh sách cũ
  useEffect(() => {
    setCueList([]);
    setCueIndex(-1);
    lastCueRef.current = -2;
    setLoopIndex(-1);
  }, [activeSubLang, pathViewFile]);

  // Đọc cue từ track phụ đề đang chọn (đọc lại khi đổi độ trễ vì thời gian cue đã bị dịch)
  useEffect(() => {
    if (!(isMouse || audioOnly) || type !== "file" || !activeSubLang) return;
    let timer;
    let tries = 0;
    const load = () => {
      const videoEl = document.getElementsByTagName("video")[0];
      const track = videoEl && videoEl.textTracks ? Array.from(videoEl.textTracks).find((t) => t.language === activeSubLang) : null;
      if (track && track.cues && track.cues.length) {
        setCueList(
          Array.from(track.cues)
            .map((c) => ({ start: c.startTime, end: c.endTime, text: cleanCueText(c.text) }))
            .filter((c) => c.text)
        );
        lastCueRef.current = -2;
      } else if (tries++ < 120) {
        timer = setTimeout(load, 500); // phụ đề tải bất đồng bộ, thử lại tối đa ~60s
      }
    };
    load();
    return () => clearTimeout(timer);
  }, [activeSubLang, subDelay, pathViewFile, audioOnly]);

  // Theo dõi thời gian video -> highlight cue hiện tại và cuộn tới nó
  useEffect(() => {
    if (!(isMouse || audioOnly) || _.isEmpty(cueList)) return;
    const id = setInterval(() => {
      const player = playerRef.current;
      if (!player) return;
      const t = player.getCurrentTime() || 0;
      let lo = 0;
      let hi = cueList.length - 1;
      let found = -1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (cueList[mid].start <= t) {
          found = mid;
          lo = mid + 1;
        } else {
          hi = mid - 1;
        }
      }
      const live = found >= 0 && t < cueList[found].end ? found : -1;
      setCueIndex((prev) => (prev === live ? prev : live));
      // Khi không có sub đang hiện: tính tỉ lệ thời gian đã trôi từ lúc sub trước kết thúc tới lúc sub kế tiếp bắt đầu
      let nextGap = null;
      const nextIdx = found + 1;
      if (live === -1 && nextIdx < cueList.length) {
        const gapStart = found >= 0 ? cueList[found].end : 0;
        const gapEnd = cueList[nextIdx].start;
        if (gapEnd - gapStart > 2) {
          // chỉ hiện thanh khi khoảng trống giữa hai sub trên 2 giây
          const p = Math.min(1, Math.max(0, (t - gapStart) / (gapEnd - gapStart)));
          nextGap = { next: nextIdx, p: Math.round(p * 100) / 100 };
        }
      }
      setGap((prev) => (JSON.stringify(prev) === JSON.stringify(nextGap) ? prev : nextGap));
      if (found !== lastCueRef.current) {
        lastCueRef.current = found;
        const panel = document.getElementById("cue_panel");
        const item = document.getElementById(`cue_${found}`);
        // Người dùng vừa tự cuộn thì không giành quyền cuộn trong 3 giây
        if (panel && item && Date.now() - userScrollRef.current > 3000) {
          panel.scrollTo({ top: item.offsetTop - panel.clientHeight / 2 + item.offsetHeight / 2, behavior: "smooth" });
        }
      }
    }, 250);
    return () => clearInterval(id);
  }, [cueList, audioOnly]);

  // Mở khung sub bên cạnh: cuộn tới câu đang phát
  useEffect(() => {
    if (!fsSide || !sideOpen) return;
    const t = setTimeout(() => {
      const panel = document.getElementById("cue_panel");
      const item = document.getElementById(`cue_${lastCueRef.current}`);
      if (panel && item) panel.scrollTop = item.offsetTop - panel.clientHeight / 2 + item.offsetHeight / 2;
    }, 60);
    return () => clearTimeout(t);
  }, [fsSide, sideOpen]);

  const seekToCue = (cue) => {
    const player = playerRef.current;
    if (!player) return;
    const target = Math.max(cue.start, 0) + 0.01;
    player.seekTo(target, "seconds");
    setStateElm({ playing: true, ...(state.duration > 0 ? { played: target / state.duration } : {}) }); // tua xong thì phát luôn nếu đang dừng
    markSeek();
  };

  // Lặp lại một phụ đề: hết cue thì tua ngay về đầu cue và phát tiếp
  useEffect(() => {
    if (loopIndex < 0) return;
    const id = setInterval(() => {
      if (loopWaitRef.current) return;
      const cue = cueList[loopIndex];
      const player = playerRef.current;
      if (!cue || !player) return;
      if (Date.now() - loopSinceRef.current < 800) return; // chờ lệnh tua ban đầu có hiệu lực
      const t = player.getCurrentTime() || 0;
      if (t < cue.start - 0.5 || t > cue.end + 0.5) {
        setLoopIndex(-1); // người dùng tua ra ngoài câu -> tắt lặp
        return;
      }
      if (t >= cue.end - 0.05) {
        // Hết câu -> tua ngay về đầu câu, không dừng; khoá ngắn để không tua lặp nhiều lần
        loopWaitRef.current = true;
        player.seekTo(cue.start + 0.01, "seconds");
        loopTimerRef.current = setTimeout(() => {
          loopWaitRef.current = false;
        }, 300);
      }
    }, 50);
    return () => {
      clearInterval(id);
      clearTimeout(loopTimerRef.current);
      loopWaitRef.current = false;
    };
  }, [loopIndex, cueList]);

  const toggleLoop = (i) => {
    if (loopIndex === i) {
      setLoopIndex(-1);
      return;
    }
    const cue = cueList[i];
    const player = playerRef.current;
    if (!cue || !player) return;
    const target = Math.max(cue.start, 0) + 0.01;
    loopSinceRef.current = Date.now();
    player.seekTo(target, "seconds");
    setLoopIndex(i);
    setStateElm({ playing: true, ...(state.duration > 0 ? { played: target / state.duration } : {}) });
  };

  const boxDelayHandle = () => {
    if (_.isEmpty(subtitles)) return;
    if (!boxDelay) {
      setIndexDelay(0);
      setBoxTracks(false);
      setBoxFont(false);
      setBoxAudio(false);
      setBoxFont(false);
      setBoxSpeed(false);
      setBoxFont(false);
    }
    setBoxDelay(!boxDelay);
  };

  const SPEED_OPTIONS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
  const SPEED_STEP = 0.25;
  const formatSpeed = (r) => `${_.round(r, 2)}x`;
  const boxSpeedHandle = () => {
    if (!boxSpeed) {
      setIndexSpeed(Math.max(0, SPEED_OPTIONS.indexOf(state.playbackRate)));
      setBoxTracks(false);
      setBoxFont(false);
      setBoxAudio(false);
      setBoxFont(false);
      setBoxDelay(false);
      setBoxFont(false);
    }
    setBoxSpeed(!boxSpeed);
  };
  // delta === null: về 1x; còn lại: tăng/giảm tương đối. Cũng nhận { set: x } để chọn thẳng một mức
  const changeSpeed = (delta) => {
    const next = delta === null ? 1 : delta && delta.set ? delta.set : _.clamp(_.round(state.playbackRate + delta, 2), 0.25, 3);
    setStateElm({ playbackRate: next });
    try {
      localStorage.setItem("playbackRate", String(next));
    } catch (e) {}
    showToast(`Tốc độ: ${formatSpeed(next)}`);
    handleAutoHide();
  };

  const changeSubDelay = (delta) => {
    const next = delta === null ? 0 : _.clamp(_.round(subDelay + delta, 1), -60, 60);
    setSubDelay(next);
    applySubDelay(next);
    showToast(`Độ trễ phụ đề: ${formatDelay(next)}`);
    handleAutoHide();
  };

  // Phụ đề tải bất đồng bộ / bị nạp lại -> áp lại độ trễ định kỳ khi đang có chỉnh
  useEffect(() => {
    applySubDelay(subDelay);
    if (subDelay === 0) return;
    const id = setInterval(() => applySubDelay(subDelay), 1000);
    return () => clearInterval(id);
  }, [subDelay]);

  // ---------- Pick thư mục để hiện ở trang Home ----------
  // Pick: POST /pick/<đường dẫn thư mục>. Bỏ pick: DELETE /pick/<tên trên Home>.
  // Cập nhật danh sách tại chỗ (không tải lại) để vị trí đang chọn không bị nhảy về đầu.
  const encodePath = (p) => p.split("/").map(encodeURIComponent).join("/");

  const togglePick = (folder) => {
    const isRootList = root === "";
    const folderPath = _.filter([root, pathName, folder.name], (elm) => !!elm).join("/");
    const request = folder.picked
      ? fetch(pickURL + encodeURIComponent(folder.pickedName || folder.name), { method: "DELETE" })
      : fetch(pickURL + encodePath(folderPath), { method: "POST" });
    request
      .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) throw new Error(data && data.error);
        if (folder.picked) {
          // Bỏ pick: ở Home thì thư mục biến mất khỏi danh sách
          setFolders((list) =>
            isRootList
              ? list.filter((f) => f.name !== folder.name)
              : list.map((f) => (f.name === folder.name ? { ...f, picked: false, pickedName: undefined } : f))
          );
          showToast(`Đã bỏ pick: ${folder.name}`);
        } else {
          setFolders((list) => list.map((f) => (f.name === folder.name ? { ...f, picked: true, pickedName: data.name } : f)));
          showToast(`Đã pick: ${folder.name} (hiện ở trang Home)`);
        }
      })
      .catch(() => showToast("Không pick được thư mục này", 3000));
  };

  const handleActionFile = (fileName, path) => {
    if (fileName) history.replace(`/${[path, fileName].join("/")}?type=file`);
  };

  // Theo dõi kích thước khung video (đổi cỡ cửa sổ, vào/ra toàn màn hình) để chữ phụ đề co giãn theo
  const [frameH, setFrameH] = useState(0);
  const [frameW, setFrameW] = useState(0);
  useEffect(() => {
    let ro;
    let timer;
    let tries = 0;
    const measure = (el) => {
      setFrameH(Math.round(el.offsetHeight));
      setFrameW(Math.round(el.offsetWidth));
    };
    const attach = () => {
      const el = document.getElementById("sample_video");
      if (el) {
        measure(el);
        if (typeof ResizeObserver !== "undefined") {
          ro = new ResizeObserver(() => measure(el));
          ro.observe(el);
        }
      } else if (tries++ < 20) {
        timer = setTimeout(attach, 300);
      }
    };
    const onWinResize = () => {
      const el = document.getElementById("sample_video");
      if (el) measure(el);
    };
    attach();
    window.addEventListener("resize", onWinResize);
    document.addEventListener("fullscreenchange", onWinResize);
    return () => {
      clearTimeout(timer);
      if (ro) ro.disconnect();
      window.removeEventListener("resize", onWinResize);
      document.removeEventListener("fullscreenchange", onWinResize);
    };
  }, [type, pathViewFile]);

  // Vùng hình video thật sự hiển thị (trừ viền đen khi khác tỉ lệ khung) — toạ độ ASS tính theo vùng này
  const [picRect, setPicRect] = useState(null);
  useEffect(() => {
    const calc = () => {
      const frame = document.getElementById("sample_video");
      const videoEl = document.getElementsByTagName("video")[0];
      if (!frame) return;
      const fw = frame.offsetWidth;
      const fh = frame.offsetHeight;
      if (!fw || !fh) return;
      const vw = videoEl ? videoEl.videoWidth : 0;
      const vh = videoEl ? videoEl.videoHeight : 0;
      let r = { left: 0, top: 0, width: fw, height: fh, vw, vh };
      if (vw && vh) {
        const k = Math.min(fw / vw, fh / vh);
        const w = vw * k;
        const h = vh * k;
        r = { left: (fw - w) / 2, top: (fh - h) / 2, width: w, height: h, vw, vh };
      }
      setPicRect((prev) =>
        prev &&
        Math.abs(prev.left - r.left) < 0.5 &&
        Math.abs(prev.top - r.top) < 0.5 &&
        Math.abs(prev.width - r.width) < 0.5 &&
        Math.abs(prev.height - r.height) < 0.5 &&
        prev.vw === r.vw &&
        prev.vh === r.vh
          ? prev
          : r
      );
    };
    calc();
    const id = setInterval(calc, 500); // video có thể được tạo sau, hoặc đổi độ phân giải giữa chừng
    window.addEventListener("resize", calc);
    return () => {
      clearInterval(id);
      window.removeEventListener("resize", calc);
    };
  }, [frameW, frameH, pathViewFile]);

  const videoH = frameH || (sample_video ? sample_video.offsetHeight : 0);
  const videoW = frameW || (sample_video ? sample_video.offsetWidth : 0);
  // Cảm ứng + khung hẹp: ẩn nút tua 2 phút (đã có chạm hai bên video) và nút âm lượng (điện thoại có phím cứng),
  // chuyển chữ thời gian lên thanh tiêu đề để 8 nút còn lại to và dễ bấm
  const containerW = sample_video ? sample_video.offsetWidth : videoW;
  const sizeW = audioOnly ? containerW || videoW : videoW; // chỉ nghe: khung video bị thu nhỏ nên lấy độ rộng khung thay vì độ rộng ảnh
  const compactTouch = touch && containerW > 0 && containerW < 700;
  // Điện thoại màn hình hẹp, chưa xem toàn màn hình: ẩn bớt nút chọn sub / font / tốc độ / audio cho đỡ chật
  const hideExtraIcons = compactTouch && !isFullSreen;
  const touchButtons = compactTouch ? 7 : 9; // số nút trên thanh điều khiển
  const touchTimeW = compactTouch ? 0 : 110; // chỗ chừa cho chữ thời gian trên thanh điều khiển
  const barPx =
    touch && containerW
      ? Math.round(Math.min(Math.max((containerW - 24 - touchTimeW) / (touchButtons + 0.2), 34), 56))
      : sizeW
        ? Math.round(Math.min(Math.max(sizeW / 28, 32), 110))
        : 50;
  const titlePx = Math.round(Math.min(Math.max((containerW || sizeW || 600) / 40, 14), 40)); // cỡ chữ tiêu đề, co giãn theo độ rộng khung
  const hideUI = hide && !audioOnly; // chỉ nghe thì thanh điều khiển luôn hiện
  const sizeBar = {
    // Nút điều khiển và chữ thời gian co giãn liên tục theo độ rộng khung video
    "--width-bar": barPx + "px",
    // Không có phụ đề: bỏ khoảng trống dành cho phụ đề/thanh điều khiển (chỉ áp dụng khi có sub)
    "--bar-gap": _.isEmpty(subtitles) ? "0px" : undefined,
    "--font-size": sizeW ? Math.round(Math.min(Math.max(sizeW / 90, touch ? 13 : 11), 26)) + "px" : "12px",
    // Chiều cao tối đa của popup chọn (sub / tốc độ / audio): không cao quá khung video (chỉ nghe: khung rất thấp nên cho tối đa 230px, popup mở lên trên)
    "--menu-max-h": audioOnly ? "230px" : videoH ? Math.max(videoH - barPx - 16, 80) + "px" : "70vh",
    "--font-size-subtitle": videoH ? Math.max(videoH / 18, 14) + "px" : "24px",
    // Tiêu đề video co giãn theo độ rộng khung video
    "--font-size-title": titlePx + "px"
  };

  const toggleAudioOnly = () => {
    if (!audioOnly && isFullSreen) handleFullSreen(false); // đang full screen thì thoát trước khi ẩn hình
    setAudioOnly(!audioOnly);
  };

  useEffect(() => {
    // Chỉ tự full screen trên TV. PC: người dùng tự bật bằng phím F / nút / double click.
    if (sample_video && type === "file" && !isMouse) {
      handleFullSreen(true);
    }
  }, [sample_video]);

  const onFullSreenEvent = (e) => {
    if (!document.fullscreenElement) {
      // TV: thoát full screen = quay về danh sách. PC: ở lại trang xem video.
      // TV: thoát full screen = quay về danh sách, trừ khi đang có popup (popup sẽ do nút back đóng)
      const popupOpen = Object.values(popupRef.current).some(Boolean);
      if (!isMouse && !popupOpen) history.replace(`/${backRootPath}`, { folder: _.last(fullPathRoot) });
      setIsFullSreen(false);
      // Thoát full (kể cả bằng cử chỉ quay lại): về màn dọc, rồi trả lại chế độ tự xoay
      if (touch) lockOrient("portrait").then(() => setTimeout(unlockOrient, 600));
    } else {
      setIsFullSreen(true);
      // Vào full: xoay ngang ngay (trừ video quay dọc)
      if (touch) {
        const v = document.querySelector("#sample_video video");
        const portraitVideo = v && v.videoWidth && v.videoHeight > v.videoWidth;
        if (!portraitVideo) lockOrient("landscape");
      }
    }
  };

  const setStateElm = (value) => {
    const newStage = _.cloneDeep(state);
    _.assign(newStage, value);
    setState(newStage);
  };

  setStateElmRef.current = setStateElm;

  const handleFullSreen = (isFullSreen) => {
    if (isFullSreen) {
      if (audioOnly) setAudioOnly(false); // bấm full screen khi đang chỉ nghe: hiện lại video
      // Cảm ứng: full screen cả khối (video + khung sub) để mở được khung sub bên cạnh
      const fsTarget = touch && stackRef.current ? stackRef.current : sample_video;
      fsTarget.requestFullscreen();
    } else if (touch) {
      // Khoá dọc trước khi thoát (trình duyệt chỉ cho khoá khi còn đang full)
      lockOrient("portrait").then(() => document.exitFullscreen());
    } else {
      document.exitFullscreen();
    }
  };

  const handleSeekMouseDown = () => {
    setStateElm({ seeking: true, seekingLine: state.played });
  };

  const handleSeekChange = (e) => {
    setStateElm({ seekingLine: parseFloat(e.target.value) });
  };

  const handleSeekMouseUp = (e) => {
    setStateElm({ seeking: false, played: state.seekingLine, playing: true }); // tua xong thì phát luôn nếu đang dừng
    playerRef.current?.seekTo(parseFloat(state.seekingLine * state.duration), "seconds");
    markSeek();
  };

  const handleChangeSeek = (isNext, seconds) => {
    let newSeconds = parseFloat(state.played * state.duration) + (isNext ? seconds || 15 : -(seconds || 15));
    newSeconds = newSeconds > 0 ? newSeconds : 0;
    setStateElm({ played: newSeconds / state.duration, playing: true }); // tua xong thì phát luôn nếu đang dừng
    playerRef.current?.seekTo(newSeconds, "seconds");
    markSeek();
  };

  // Sau một lần tua, các sự kiện chuột/chạm ngay sau đó (click, di chuột) không được kéo thời gian ẩn về 3 giây
  const seekAtRef = useRef(0);
  const markSeek = () => {
    seekAtRef.current = Date.now();
    handleAutoHide(null, 1000);
  };

  const handleAutoHide = (event, delay = 3000) => {
    const ms = delay === 3000 && Date.now() - seekAtRef.current < 1500 ? 1000 : delay;
    setHide(false);
    clearTimeout(currentRef.current);
    // Chế độ chuột: luôn tự ẩn sau 3s, không phụ thuộc indexFile (indexFile chỉ dùng cho chế độ remote)
    // Chế độ remote: chỉ tự ẩn khi đang ở thanh điều khiển chính (indexFile === 0)
    if (isMouse || indexFile === 0) {
      currentRef.current = setTimeout(() => {
        setHide(true);
        setBoxTracks(false);
        setBoxFont(false);
        setBoxAudio(false);
        setBoxFont(false);
        setBoxDelay(false);
        setBoxFont(false);
        setBoxSpeed(false);
        setBoxFont(false);
        if (!isMouse) setIndexFile(0);
      }, ms);
    }
  };

  // Đang dừng rồi chạy lại (bấm play, tua, phím tắt...): giao diện điều khiển ẩn sau 1 giây
  const prevPlayingRef = useRef(state.playing);
  useEffect(() => {
    const wasPlaying = prevPlayingRef.current;
    prevPlayingRef.current = state.playing;
    if (!wasPlaying && state.playing) handleAutoHide(null, 1000);
  }, [state.playing]);

  const getSubtitles = () => {
    fetch(trasksURL + pathViewFile)
      .then((response) => response.json())
      .then((data) => {
        if (_.isArray(data)) {
          setSubtitles(data);
        } else {
          setTimeout(() => {
            getSubtitles();
          }, 3000);
        }
      });
  };

  const actionInListFileHandle = (action) => {
    let newIndex = action ? indexFile + 1 : indexFile - 1;
    if (newIndex < 0) newIndex = folders.length - 1;
    if (newIndex >= folders.length) newIndex = 0;
    setIndexFile(newIndex);
  };

  const upDownVideoHandle = (action) => {
    if (boxDelay) {
      if (!action && indexDelay === 0) {
        setBoxDelay(false);
        setBoxFont(false);
        setIndexFile(0);
        return;
      }
      let newIndex = action ? indexDelay + 1 : indexDelay - 1;
      if (newIndex < 0) newIndex = 2;
      if (newIndex > 2) newIndex = 0;
      setIndexDelay(newIndex);
      return;
    }
    if (boxAudio) {
      if (!action && indexAudio === 0) {
        setBoxAudio(false);
        setBoxFont(false);
        setIndexFile(0);
        return;
      }
      let newIndex = action ? indexAudio + 1 : indexAudio - 1;
      if (newIndex < 0) newIndex = audioList.length - 1;
      if (newIndex >= audioList.length) newIndex = 0;
      setIndexAudio(newIndex);
      return;
    }
    if (boxFont) {
      if (!action && indexFont === 0) {
        setBoxFont(false);
        setIndexFile(0);
        return;
      }
      const n = SUB_FONT_CHOICES.length;
      setIndexFont(((action ? indexFont + 1 : indexFont - 1) + n) % n);
      return;
    }
    if (boxSpeed) {
      if (!action && indexSpeed === 0) {
        setBoxSpeed(false);
        setIndexFile(0);
        return;
      }
      const n = SPEED_OPTIONS.length;
      setIndexSpeed(((action ? indexSpeed + 1 : indexSpeed - 1) + n) % n);
      return;
    }
    if (!boxTracks) {
      let newIndex = action ? 3 : 0;
      if (indexFile === 0 && !action) {
        setHide(true);
        if (indexFile === 3 && action) setIndexFile(0);
      } else {
        setIndexFile(newIndex);
      }
    } else {
      // Danh sách điều hướng: Sub 1 (Off + n sub) rồi tới Sub 2 (Off + các sub khác Sub 1), khi có từ 2 sub trở lên
      if (!action && indexSub === 0) {
        setBoxTracks(false);
        setBoxFont(false);
        setIndexFile(0);
        return;
      }
      const subCount = subtitles.length;
      const sub2Count = subCount > 1 ? subtitles.filter((sub) => sub.language !== activeSubLang).length + 1 : 0;
      const maxIndex = subCount + sub2Count;
      let newIndex = action ? indexSub + 1 : indexSub - 1;
      if (newIndex < 0) newIndex = maxIndex;
      if (newIndex > maxIndex) newIndex = 0;
      setIndexSub(newIndex);
    }
  };

  const leftRightVideoHandle = (action) => {
    if (indexFile === 0) {
      handleChangeSeek(action);
    } else {
      let newIndex = action ? indexFile + 1 : indexFile - 1;
      if (newIndex < 1) newIndex = 12;
      if (newIndex > 12) newIndex = 1;
      setIndexFile(newIndex);
    }
  };

  const boxTrackHandle = () => {
    if (!_.isEmpty(subtitles) && !boxTracks) {
      const index = _.findIndex(subtitles, (s) => !!s.default);
      setIndexSub(index + 1);
    }
    if (!_.isEmpty(subtitles)) {
      setBoxAudio(false);
      setBoxFont(false);
      setBoxDelay(false);
      setBoxFont(false);
      setBoxSpeed(false);
      setBoxFont(false);
      setBoxTracks(!boxTracks);
    }
  };

  // ---------- Điều khiển bằng bàn phím ----------
  const SEEK_STEP = 10; // giây, phím ← →
  const SEEK_STEP_LONG = 60; // giây, Shift + ← →

  const seekBy = (delta) => {
    const player = playerRef.current;
    if (!player) return;
    const current = player.getCurrentTime() || 0;
    const max = state.duration > 0 ? Math.max(state.duration - 1, 0) : Infinity;
    const target = Math.min(Math.max(current + delta, 0), max);
    player.seekTo(target, "seconds");
    setStateElm({ playing: true, ...(state.duration > 0 ? { played: target / state.duration } : {}) }); // tua xong thì phát luôn nếu đang dừng
    markSeek();
  };

  const togglePlay = () => {
    setStateElm({ playing: !state.playing });
    handleAutoHide();
  };

  const changeVolume = (delta) => {
    const volume = Math.min(Math.max(_.round(state.volume + delta, 2), 0), 1);
    setStateElm({ volume, muted: false });
    handleAutoHide();
  };

  // Gắn lại listener sau mỗi lần render để handler luôn thấy state mới nhất
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const tag = e.target && e.target.tagName;
      if (tag === "TEXTAREA" || (tag === "INPUT" && e.target.type !== "range")) return;

      // Tránh việc phím Space/Enter vừa chạy shortcut vừa "bấm" nút đang được focus
      const active = document.activeElement;
      if (active && (active.tagName === "BUTTON" || (active.tagName === "INPUT" && active.type === "range"))) {
        active.blur();
      }

      if (type === "file") {
        switch (e.key) {
          case " ":
          case "Spacebar":
          case "Enter":
          case "k":
          case "K":
          case "MediaPlayPause":
            e.preventDefault();
            if (!e.repeat) togglePlay();
            break;
          case "MediaPlay":
            e.preventDefault();
            setStateElm({ playing: true });
            break;
          case "MediaPause":
            e.preventDefault();
            setStateElm({ playing: false });
            break;
          case "ArrowRight":
            e.preventDefault();
            seekBy(e.shiftKey ? SEEK_STEP_LONG : SEEK_STEP);
            break;
          case "ArrowLeft":
            e.preventDefault();
            seekBy(-(e.shiftKey ? SEEK_STEP_LONG : SEEK_STEP));
            break;
          case "l":
          case "L":
          case "MediaFastForward":
            e.preventDefault();
            seekBy(SEEK_STEP_LONG / 6);
            break;
          case "j":
          case "J":
          case "MediaRewind":
            e.preventDefault();
            seekBy(-SEEK_STEP_LONG / 6);
            break;
          case "ArrowUp":
            e.preventDefault();
            changeVolume(0.1);
            break;
          case "ArrowDown":
            e.preventDefault();
            changeVolume(-0.1);
            break;
          case "m":
          case "M":
            e.preventDefault();
            setStateElm({ muted: !state.muted });
            break;
          case "a":
          case "A":
            e.preventDefault();
            if (!e.repeat) cycleAudio();
            break;
          case "]":
          case ">":
            e.preventDefault();
            changeSpeed(SPEED_STEP);
            break;
          case "[":
          case "<":
            e.preventDefault();
            changeSpeed(-SPEED_STEP);
            break;
          case "\\":
            e.preventDefault();
            changeSpeed(null);
            break;
          case "h":
          case "H":
            e.preventDefault();
            changeSubDelay(e.shiftKey ? SUB_DELAY_STEP_LONG : SUB_DELAY_STEP);
            break;
          case "g":
          case "G":
            e.preventDefault();
            changeSubDelay(-(e.shiftKey ? SUB_DELAY_STEP_LONG : SUB_DELAY_STEP));
            break;
          case "n":
          case "N":
          case "PageDown":
          case "MediaTrackNext":
            e.preventDefault();
            handleActionFile(nextFile, backRootPath);
            break;
          case "p":
          case "P":
          case "PageUp":
          case "MediaTrackPrevious":
            e.preventDefault();
            handleActionFile(previousFile, backRootPath);
            break;
          case "f":
          case "F":
            e.preventDefault();
            handleFullSreen(!isFullSreen);
            break;
          case "v":
          case "V":
            // Chỉ nghe tiếng (ẩn / hiện video)
            e.preventDefault();
            if (isMouse && !e.repeat) toggleAudioOnly();
            break;
          case "Escape":
          case "Backspace":
            // Đang full screen thì Esc do trình duyệt xử lý (thoát full screen); lần sau mới quay về danh sách
            if (!document.fullscreenElement) {
              e.preventDefault();
              if (closePopupIfOpen()) break;
              history.replace(`/${backRootPath}`, { folder: _.last(fullPathRoot) });
            }
            break;
          default:
            break;
        }
      } else {
        // Màn hình danh sách thư mục / file
        switch (e.key) {
          case "ArrowUp":
          case "ArrowLeft":
            e.preventDefault();
            if (!_.isEmpty(folders)) actionInListFileHandle(false);
            break;
          case "ArrowDown":
          case "ArrowRight":
            e.preventDefault();
            if (!_.isEmpty(folders)) actionInListFileHandle(true);
            break;
          case "Enter": {
            e.preventDefault();
            const link = document.getElementsByClassName("f-active")[0]?.getElementsByTagName("a")[0];
            if (link) link.click();
            break;
          }
          case "Backspace":
            if (root !== "") {
              e.preventDefault();
              history.replace(`/${backRootPath}`, { folder: _.last(fullPathRoot) });
            }
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  // ---------- Chạm hai bên video để tua (màn hình cảm ứng) ----------
  const TAP_ZONE = 0.28; // mỗi bên chiếm 28% bề ngang video
  const TAP_SEEK = 10; // giây mỗi lần chạm
  const [tapHint, setTapHint] = useState(null); // { side, total }
  const tapAccumRef = useRef({ side: "", total: 0, time: 0 });
  const tapHintTimerRef = useRef(null);

  const tapZoneOf = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / (rect.width || 1);
    return x < TAP_ZONE ? "left" : x > 1 - TAP_ZONE ? "right" : "center";
  };

  const DOUBLE_TAP_MS = 280; // hai lần chạm cách nhau không quá thời gian này mới tính là chạm đôi
  const tapPendingRef = useRef(null); // lần chạm đơn ở hai bên đang chờ xem có phải chạm đôi không
  const playingRef = useRef(true);
  playingRef.current = state.playing;

  const doTapSeek = (zone) => {
    const now = Date.now();
    const acc = tapAccumRef.current;
    // chạm liên tiếp cùng một bên thì cộng dồn số giây hiển thị
    const total = acc.side === zone && now - acc.time < 900 ? acc.total + TAP_SEEK : TAP_SEEK;
    tapAccumRef.current = { side: zone, total, time: now };
    seekBy(zone === "left" ? -TAP_SEEK : TAP_SEEK);
    setTapHint({ side: zone, total });
    clearTimeout(tapHintTimerRef.current);
    tapHintTimerRef.current = setTimeout(() => setTapHint(null), 800);
  };

  const handleOverlayTap = (e) => {
    // Bấm ra ngoài chữ sub (phát / tạm dừng): bỏ tô đen từ đang chọn
    const sel = window.getSelection && window.getSelection();
    if (sel && sel.rangeCount) sel.removeAllRanges();
    if (touch) {
      const zone = tapZoneOf(e);
      if (zone !== "center") {
        const now = Date.now();
        const pend = tapPendingRef.current;
        const acc = tapAccumRef.current;
        const chaining = acc.side === zone && now - acc.time < 900; // đang tua liên tục: mỗi cú chạm tiếp theo tua tiếp
        const isDouble = pend && pend.zone === zone && now - pend.time < DOUBLE_TAP_MS;
        if (chaining || isDouble) {
          if (pend) clearTimeout(pend.timer);
          tapPendingRef.current = null;
          doTapSeek(zone); // chạm đôi -> tua
          return;
        }
        // Chạm 1 lần: chờ xem có chạm lần 2 không; nếu không thì phát / dừng video
        if (pend) {
          clearTimeout(pend.timer);
          if (pend.zone !== zone) setStateElmRef.current({ playing: !playingRef.current }); // chạm đơn bên kia vẫn tính là phát / dừng
        }
        const timer = setTimeout(() => {
          tapPendingRef.current = null;
          setStateElmRef.current({ playing: !playingRef.current });
        }, DOUBLE_TAP_MS);
        tapPendingRef.current = { zone, time: now, timer };
        return;
      }
    }
    setStateElm({ playing: !state.playing });
  };

  const handleOverlayDoubleClick = (e) => {
    // TV: bấm OK nhanh sẽ thành "double click"; ở TV thoát full screen = quay về danh sách nên tuyệt đối không xử lý double click
    if (!isMouse) return;
    // Chạm 2 lần ở hai bên = tua 2 lần, không bật/tắt full screen
    if (touch && tapZoneOf(e) !== "center") return;
    handleFullSreen(!isFullSreen);
  };

  // ---------- Remote kiểu con trỏ: đọc hướng di chuyển + lọc "nảy ngược" ----------
  // Khi con trỏ chạm mép màn hình, một số TV đẩy con trỏ ngược lại ngay sau khi nhận nút (vd bấm trái -> sang trái 1 nấc
  // rồi tự sang phải). Bỏ qua sự kiện ngược chiều trên cùng trục nếu nó xảy ra ngay sau một thao tác.
  const REMOTE_MIN_MOVE = 5; // px, nhỏ hơn thì coi là nhiễu
  const REMOTE_BOUNCE_MS = 250; // cửa sổ thời gian để coi sự kiện ngược chiều là "nảy lại"
  const lastRemoteMoveRef = useRef({ axis: "", dir: 0, time: 0 });

  const readRemoteMove = (event) => {
    const { movementX, movementY } = event;
    let axis = "";
    let value = 0;
    if (!movementX && movementY && Math.abs(movementY) > REMOTE_MIN_MOVE) {
      axis = "y";
      value = movementY;
    } else if (movementX && !movementY && Math.abs(movementX) > REMOTE_MIN_MOVE) {
      axis = "x";
      value = movementX;
    } else {
      return null;
    }
    const dir = value > 0 ? 1 : -1;
    const now = Date.now();
    const last = lastRemoteMoveRef.current;
    if (last.axis === axis && last.dir === -dir && now - last.time < REMOTE_BOUNCE_MS) {
      lastRemoteMoveRef.current = { ...last, time: now }; // gia hạn: chuỗi nảy nhiều nhịp vẫn bị bỏ qua
      return null;
    }
    lastRemoteMoveRef.current = { axis, dir, time: now };
    return { axis, forward: dir > 0 };
  };

  return (
    <>
      <div
        className="App"
        onMouseMove={(event) => {
          if (!isMouse && !isFullSreen) {
            const move = readRemoteMove(event);
            if (move) actionInListFileHandle(move.forward);
          }
        }}
        onClick={() => {
          if (!isMouse) {
            document.getElementsByClassName("f-active")[0].getElementsByTagName("a")[0].click();
          }
        }}
      >
        <header className="flex min-h-screen flex-col items-center justify-start bg-[#282c34] text-[calc(10px_+_2vmin)] text-white max-[800px]:min-h-dvh max-[800px]:overflow-x-clip">
          <div
            className="mx-auto box-border w-[1000px] max-w-full overflow-auto text-left text-[20px] h-[900px] max-[800px]:h-auto max-[800px]:w-full max-[800px]:overflow-visible max-[800px]:px-3 max-[800px]:pt-3 max-[800px]:pb-8 max-[800px]:text-[16px]"
            id="body"
            style={isMouse && type === "file" ? { width: "96vw", maxWidth: "1800px", height: "auto", overflow: "visible" } : undefined}
          >
            {/* Hàng đầu trang: nút quay lại (icon) + đường dẫn mục. Trang xem file không hiện tên file. */}
            <div className="flex items-start gap-3 mb-6 min-w-0 pt-4 compact:items-center compact:gap-2 compact:mb-2 compact:px-0 compact:pb-0">
              {root !== "" && (
                <Link
                  id={`back_0`}
                  className="flex-none inline-flex items-center justify-center w-10 h-10 rounded-full text-[aliceblue] no-underline [-webkit-tap-highlight-color:transparent] outline-none [&_svg]:w-[26px] [&_svg]:h-[26px] hover:bg-[rgba(255,255,255,0.14)] focus-visible:bg-[rgba(255,255,255,0.14)] compact:w-[34px] compact:h-[34px] compact:[&_svg]:w-[22px] compact:[&_svg]:h-[22px]"
                  to={`/${backRootPath}`}
                  title="Quay lại"
                  aria-label="Quay lại"
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M19 12H5" />
                    <path d="M11 6l-6 6 6 6" />
                  </svg>
                </Link>
              )}
              <div className="flex-[1_1_auto] min-w-0 pt-[7px] leading-[1.3] [overflow-wrap:anywhere] compact:pt-0 compact:text-[15px]">
                <b>
                  {root !== "" ? (
                    <Link id={`path_0`} to="/">
                      Home
                    </Link>
                  ) : (
                    "Home"
                  )}
                </b>
                {(type === "file" ? _.dropRight(fullPathRoot) : fullPathRoot).map((path, index, crumbs) => {
                  const currentPathArr = _.dropRight(fullPathRoot, fullPathRoot.length - index - 1);
                  const isCurrent = type !== "file" && index + 1 === crumbs.length; // thư mục đang mở: chỉ hiện chữ
                  return (
                    <b key={index}>
                      {" / "}
                      {root !== "" && !isCurrent && (
                        <Link id={`path_${index + 1}`} to={`/${currentPathArr.join("/")}`}>
                          {path}
                        </Link>
                      )}
                      {root !== "" && isCurrent && path}
                    </b>
                  );
                })}
              </div>
              {isMouse && (
                <div className="ml-auto flex flex-wrap justify-end gap-2 shrink-0 min-w-0 max-w-full compact:gap-1.5">
                  {type === "file" && (
                    <button
                      type="button"
                      className={`inline-flex items-center gap-1.5 px-3 py-1 text-[15px] leading-[1.4] text-white no-underline whitespace-nowrap border border-[rgba(255,255,255,0.35)] rounded-lg hover:bg-[rgba(255,255,255,0.14)] focus-visible:bg-[rgba(255,255,255,0.14)] hover:border-[rgba(255,255,255,0.7)] focus-visible:border-[rgba(255,255,255,0.7)] compact:box-border compact:w-[34px] compact:h-[34px] compact:p-0 compact:justify-center compact:text-[17px] compact:rounded-full bg-transparent font-[inherit] text-white cursor-pointer ${audioOnly ? "!border-[#ffd700] !bg-[rgba(255,215,0,0.2)]" : ""}`}
                      onClick={toggleAudioOnly}
                      aria-pressed={audioOnly}
                      title={audioOnly ? "Hiện video (V)" : "Chỉ nghe tiếng, ẩn video (V)"}
                      aria-label={audioOnly ? "Hiện video" : "Chỉ nghe"}
                    >
                      <svg width="16" height="16" viewBox="0 0 36 36" fill="currentColor" aria-hidden="true">
                        {audioOnly ? (
                          // đang chỉ nghe: máy quay = bấm để hiện lại video
                          <path d="M8 11h14a2 2 0 0 1 2 2v3.5l5-3.5v10l-5-3.5V23a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V13a2 2 0 0 1 2-2z" />
                        ) : (
                          // tai nghe = bấm để chỉ nghe tiếng
                          <path d="M18 8C12.5 8 8 12.5 8 18v6c0 1.1.9 2 2 2h2v-7h-2c0-4.4 3.6-8 8-8s8 3.6 8 8h-2v7h2c1.1 0 2-.9 2-2v-6c0-5.5-4.5-10-10-10z" />
                        )}
                      </svg>
                      <span className="compact:hidden">{audioOnly ? "Hiện video" : "Chỉ nghe"}</span>
                    </button>
                  )}
                  {type === "file" && !_.isEmpty(subtitles) && (
                    <button
                      type="button"
                      className={`inline-flex items-center gap-1.5 px-3 py-1 text-[15px] leading-[1.4] text-white no-underline whitespace-nowrap border border-[rgba(255,255,255,0.35)] rounded-lg hover:bg-[rgba(255,255,255,0.14)] focus-visible:bg-[rgba(255,255,255,0.14)] hover:border-[rgba(255,255,255,0.7)] focus-visible:border-[rgba(255,255,255,0.7)] compact:box-border compact:w-[34px] compact:h-[34px] compact:p-0 compact:justify-center compact:text-[17px] compact:rounded-full bg-transparent font-[inherit] text-white cursor-pointer ${cuePanelHidden ? "!border-[#ffd700] !bg-[rgba(255,215,0,0.2)]" : ""}`}
                      onClick={() => setCuePanelHidden(!cuePanelHidden)}
                      aria-pressed={cuePanelHidden}
                      title={cuePanelHidden ? "Hiện khung phụ đề bên phải" : "Ẩn khung phụ đề bên phải"}
                      aria-label={cuePanelHidden ? "Hiện khung phụ đề" : "Ẩn khung phụ đề"}
                    >
                      <svg width="16" height="16" viewBox="0 0 36 36" fill="currentColor" aria-hidden="true">
                        <path d="M5 8h18v20H5zm20 0h6v20h-6z" />
                        {cuePanelHidden && <path d="M4 4l28 28" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />}
                      </svg>
                      <span className="compact:hidden">{cuePanelHidden ? "Hiện khung sub" : "Ẩn khung sub"}</span>
                    </button>
                  )}
                  <a
                    className="inline-flex items-center gap-1.5 px-3 py-1 text-[15px] leading-[1.4] text-white no-underline whitespace-nowrap border border-[rgba(255,255,255,0.35)] rounded-lg hover:bg-[rgba(255,255,255,0.14)] focus-visible:bg-[rgba(255,255,255,0.14)] hover:border-[rgba(255,255,255,0.7)] focus-visible:border-[rgba(255,255,255,0.7)] compact:box-border compact:w-[34px] compact:h-[34px] compact:p-0 compact:justify-center compact:text-[17px] compact:rounded-full"
                    href="/translate-words"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Danh sách từ đã lưu"
                    aria-label="Từ đã lưu"
                  >
                    <span aria-hidden="true">★</span>
                    <span className="compact:hidden">Từ đã lưu</span>
                  </a>
                  <a
                    className="inline-flex items-center gap-1.5 px-3 py-1 text-[15px] leading-[1.4] text-white no-underline whitespace-nowrap border border-[rgba(255,255,255,0.35)] rounded-lg hover:bg-[rgba(255,255,255,0.14)] focus-visible:bg-[rgba(255,255,255,0.14)] hover:border-[rgba(255,255,255,0.7)] focus-visible:border-[rgba(255,255,255,0.7)] compact:box-border compact:w-[34px] compact:h-[34px] compact:p-0 compact:justify-center compact:text-[17px] compact:rounded-full"
                    href="/translate-settings"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Cấu hình dịch: ngôn ngữ, Gemini, đồng bộ Google Sheet"
                    aria-label="Cấu hình dịch"
                  >
                    <span aria-hidden="true">⚙</span>
                    <span className="compact:hidden">Cấu hình dịch</span>
                  </a>
                </div>
              )}
            </div>
            {type !== "file" ? (
              folders.map((folder, index) => {
                const fullPath = _.filter([root, pathName, folder.name], (elm) => !!elm).join("/");
                return (
                  <div
                    className={`App-item py-[5px] max-[800px]:flex max-[800px]:items-start max-[800px]:py-[9px] ${indexFile === index ? "f-active" : ""}`}
                    id={`file_${index}`}
                    key={index}
                  >
                    <img
                      className="max-[800px]:w-[18px] max-[800px]:flex-none max-[800px]:mt-[3px]"
                      src={folder.type === "file" ? fileIcon : folderIcon}
                      alt="icon"
                    />
                    <Link to={`/${fullPath}${folder.type === "file" ? "?type=file" : ""}`}>{folder.name}</Link>
                    {/* Home: ổ đĩa không có nút, thư mục đã pick có nút "Bỏ pick". Trong thư mục: thư mục con có nút Pick. TV (remote) không hiện nút. */}
                    {isMouse && folder.type === "folder" && (root !== "" || folder.picked) && (
                      <button
                        type="button"
                        className={`ml-3 rounded-full border border-[#808080] bg-transparent px-2.5 py-px align-middle flex-none cursor-pointer text-[0.7em] leading-[1.6] text-[#bbb] hover:border-[#61dafb] hover:text-[#61dafb] max-[800px]:ml-auto max-[800px]:px-3 max-[800px]:py-1 max-[800px]:text-[0.8em] ${folder.picked ? "!border-[#ffd700] !text-[#ffd700]" : ""}`}
                        title={folder.picked ? "Bỏ pick (xoá khỏi trang Home)" : "Pick để hiện ở trang Home"}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          togglePick(folder);
                        }}
                      >
                        {folder.picked ? (root === "" ? "Bỏ pick" : "Đã pick ✓") : "Pick"}
                      </button>
                    )}
                  </div>
                );
              })
            ) : (
              <div
                ref={stackRef}
                style={
                  isMouse
                    ? fsSide
                      ? { display: "flex", flexDirection: "row", gap: 0, alignItems: "stretch", width: "100vw", height: "100vh", background: "#000" }
                      : layoutStacked
                        ? { display: "flex", flexDirection: "column", gap: "12px", width: "100%" }
                        : { display: "flex", gap: "12px", alignItems: "flex-start" }
                    : undefined
                }
              >
                <div
                  className="player-wrapper"
                  style={
                    isMouse
                      ? fsSide
                        ? { height: "100%", flex: 1, minWidth: 0 }
                        : audioOnly
                          ? { width: "100%", height: 0, overflow: "hidden", marginBottom: "-12px" } // chỉ nghe: ẩn hẳn cả khung video lẫn thanh điều khiển (video vẫn chạy); -12px bù khoảng cách giữa hai khối xếp dọc
                          : stacked
                            ? { width: "100%", height: Math.round((bodyW * 9) / 16) + "px" } // video 16:9 chiếm hết bề ngang
                            : { height: "80vh", flex: 1, minWidth: 0 }
                      : undefined
                  }
                >
                  <div
                    onMouseMove={(event) => {
                      handleAutoHide();
                      if (!isMouse && isFullSreen) {
                        const move = readRemoteMove(event);
                        if (move) {
                          if (move.axis === "y") upDownVideoHandle(move.forward);
                          else leftRightVideoHandle(move.forward);
                        }
                      }
                    }}
                    onClick={() => {
                      handleAutoHide();
                      if (!isMouse) {
                        if (indexFile === 0) {
                          setStateElm({ playing: !state.playing });
                        } else if (boxDelay) {
                          document.getElementsByClassName("d-active")[0]?.click();
                        } else if (boxAudio) {
                          document.getElementsByClassName("a-active")[0]?.click();
                        } else if (boxFont) {
                          document.getElementsByClassName("fo-active")[0]?.click();
                        } else if (boxSpeed) {
                          document.getElementsByClassName("sp-active")[0]?.click();
                        } else if (boxTracks) {
                          document.getElementsByClassName("s-active")[0]?.click();
                        } else {
                          document.getElementsByClassName("f-active")[0].click();
                        }
                      }
                    }}
                    id="sample_video"
                    className={`v-vlite ${state.playing ? "v-playing" : "v-paused"} ${hideUI ? "nocursor" : ""} ${isMouse ? "" : "v-remote"} ${audioOnly ? "audio-only" : ""}`}
                    style={sizeBar}
                  >
                    {!isMouse && <div className="mang"></div>}
                    {!!subtitles && (
                      <ReactPlayer
                        ref={playerRef}
                        className="react-player vlite-js"
                        // style={{ "--shadow": borderText(5, "#000") }}
                        controls={state.controls}
                        url={mediaSrc || publicURL + pathViewFile}
                        pip={state.pip}
                        playing={state.playing}
                        light={state.light}
                        loop={state.loop}
                        playbackRate={state.playbackRate}
                        volume={state.volume}
                        muted={state.muted}
                        onReady={() => {
                          if (resumeAtRef.current !== null && playerRef.current) {
                            playerRef.current.seekTo(resumeAtRef.current, "seconds");
                            resumeAtRef.current = null;
                          }
                        }}
                        onDuration={(duration) => setStateElm({ duration: duration })}
                        onEnded={() => handleActionFile(nextFile, backRootPath)}
                        onProgress={(stage) => setStateElm({ played: stage.played })}
                        config={{
                          attributes: {
                            crossOrigin: "anonymous"
                          },
                          file: {
                            tracks: subtitles.map((sub, index) => ({
                              kind: "subtitles",
                              src: subtitlesURL + pathViewFile + `?language=${sub.language}`,
                              srcLang: sub.language,
                              default: true,
                              className: "subtitle-track"
                            }))
                          }
                        }}
                      />
                    )}

                    {!audioOnly &&
                      buildAssLayer(liveCues, assMeta, picRect, {
                        secondary: secLang ? liveCues2 : [],
                        controlsHidden: hide && state.playing,
                        onGrab: () => state.playing && setStateElm({ playing: false }),
                        saved: savedMatcher,
                        hover: isMouse && !touch,
                        onWord: openTranslate
                      })}
                    {fsSide && !_.isEmpty(subtitles) && (
                      <button
                        type="button"
                        aria-label={sideOpen ? "Đóng khung phụ đề" : "Mở khung phụ đề"}
                        title={sideOpen ? "Đóng khung phụ đề" : "Mở khung phụ đề"}
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSide();
                        }}
                        onDoubleClick={(e) => e.stopPropagation()}
                        onMouseDown={(e) => e.stopPropagation()}
                        onTouchStart={(e) => e.stopPropagation()}
                        onTouchEnd={(e) => e.stopPropagation()}
                        style={{
                          position: "absolute",
                          right: 0,
                          top: "50%",
                          transform: "translateY(-50%)",
                          zIndex: 15,
                          width: "40px",
                          height: "72px",
                          border: 0,
                          borderRadius: "10px 0 0 10px",
                          background: "rgba(0,0,0,0.55)",
                          color: "#fff",
                          fontSize: "20px",
                          padding: 0,
                          opacity: hideUI ? 0 : 1,
                          pointerEvents: hideUI ? "none" : "auto",
                          transition: "opacity .25s"
                        }}
                      >
                        {sideOpen ? "▶" : "◀"}
                      </button>
                    )}
                    {trWord && !audioOnly && (
                      <TranslatePopup
                        key={trWord.id}
                        apiBase={`http://${hostname}:8081`}
                        text={trWord.text}
                        anchor={trWord.anchor}
                        hoverId={trWord.hoverId}
                        onClose={() => setTrWord(null)}
                      />
                    )}

                    {!!toast && (
                      <div
                        style={{
                          position: "absolute",
                          top: "12px",
                          right: "12px",
                          zIndex: 20,
                          padding: "8px 16px",
                          borderRadius: 6,
                          background: "rgba(0,0,0,0.75)",
                          color: "#fff",
                          fontSize: "var(--font-size)",
                          pointerEvents: "none"
                        }}
                      >
                        {toast}
                      </div>
                    )}
                    <div
                      className={`v-topBar flex items-center gap-3 absolute top-0 left-0 w-full h-auto min-h-[calc(var(--font-size-title,24px)*1.5)] !pb-[calc(var(--font-size-title,24px)*0.5)] !pt-[5px] !pl-[15px] !pr-[10px] text-left [background:linear-gradient(180deg,#000,hsla(0,0%,100%,0))] [transition:.25s_ease-in] ${hideUI ? "ui-hidden" : ""}`}
                    >
                      <span className="v-topTitle flex-1 min-w-0 whitespace-nowrap overflow-hidden text-ellipsis !text-[length:var(--font-size-title,24px)]">
                        {fileName}
                      </span>
                      {compactTouch && (
                        <span className="v-topTime shrink-0 whitespace-nowrap !text-[calc(var(--font-size-title,24px)*0.85)]">
                          <Duration seconds={state.duration * (state.seeking ? state.seekingLine : state.played)}></Duration>
                          &nbsp;/&nbsp;
                          <Duration seconds={state.duration}></Duration>
                        </span>
                      )}
                      {isMouse && (
                        <button
                          type="button"
                          title={audioOnly ? "Hiện video (V)" : "Chỉ nghe tiếng, ẩn video (V)"}
                          aria-pressed={audioOnly}
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleAudioOnly();
                          }}
                          style={{
                            flexShrink: 0,
                            position: "relative",
                            zIndex: 31, // nằm trên lớp bắt bấm của video
                            width: Math.round(titlePx * 1.9) + "px",
                            height: Math.round(titlePx * 1.9) + "px",
                            padding: 0,
                            borderRadius: "50%",
                            border: "1px solid " + (audioOnly ? "#ffd700" : "rgba(255,255,255,0.5)"),
                            background: audioOnly ? "rgba(255,215,0,0.25)" : "rgba(255,255,255,0.15)",
                            cursor: "pointer",
                            pointerEvents: hideUI ? "none" : "auto"
                          }}
                        >
                          <svg width="70%" height="70%" viewBox="0 0 36 36" fill="#fff" aria-hidden="true">
                            {audioOnly ? (
                              // đang chỉ nghe: biểu tượng máy quay = bấm để hiện lại video
                              <path d="M8 11h14a2 2 0 0 1 2 2v3.5l5-3.5v10l-5-3.5V23a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V13a2 2 0 0 1 2-2z" />
                            ) : (
                              // tai nghe = bấm để chỉ nghe tiếng
                              <path d="M18 8C12.5 8 8 12.5 8 18v6c0 1.1.9 2 2 2h2v-7h-2c0-4.4 3.6-8 8-8s8 3.6 8 8h-2v7h2c1.1 0 2-.9 2-2v-6c0-5.5-4.5-10-10-10z" />
                            )}
                          </svg>
                        </button>
                      )}
                    </div>
                    <div
                      className="v-overlayVideo"
                      // Chế độ TV: màng che nằm trên cả lớp sub (z-index 15) và cửa sổ dịch (z-index 2147483000), và phủ KÍN cả vùng thanh điều khiển
                      // (height 100%) để cú bấm thật không lọt xuống nút nào (vd nút full screen khi con trỏ kẹt ở góc dưới bên phải).
                      // Mọi thao tác của remote đi qua onClick của #sample_video (focus bằng indexFile + .click() trực tiếp lên nút).
                      style={isMouse ? undefined : { zIndex: 2147483647, height: "100%" }}
                      onClick={isMouse ? handleOverlayTap : undefined}
                      onDoubleClick={isMouse ? handleOverlayDoubleClick : (e) => e.stopPropagation()}
                    ></div>
                    {touch && tapHint && (
                      <div
                        style={{
                          position: "absolute",
                          top: "45%",
                          [tapHint.side === "left" ? "left" : "right"]: "10%",
                          transform: "translateY(-50%)",
                          zIndex: 20,
                          padding: "0.5em 1em",
                          borderRadius: "999px",
                          background: "rgba(0,0,0,0.65)",
                          color: "#fff",
                          fontSize: "calc(var(--font-size) * 1.6)",
                          whiteSpace: "nowrap",
                          pointerEvents: "none"
                        }}
                      >
                        {tapHint.side === "left" ? `« ${tapHint.total} giây` : `${tapHint.total} giây »`}
                      </div>
                    )}
                    <button
                      className="v-bigPlay absolute left-1/2 top-1/2 z-[2] [transform:translateX(-50%)_translateY(-50%)] [height:calc(var(--width-bar,50px)*1.2)] [width:calc(var(--width-bar,50px)*1.2)] flex items-center justify-center p-0 border-none outline-none cursor-pointer appearance-none [background:none] [color:inherit] [font-family:inherit] [font-size:inherit] opacity-90 hover:opacity-100 [transition:opacity_0.25s_ease] [&_svg]:fill-white [&_svg]:h-full [&_svg]:w-full [&_svg]:opacity-90 [&_svg]:[transition:opacity_0.25s_ease]"
                      aria-label="Play"
                      onClick={() => setStateElm({ playing: !state.playing })}
                    >
                      <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM7.5 12.67V7.33c0-.79.88-1.27 1.54-.84l4.15 2.67a1 1 0 0 1 0 1.68l-4.15 2.67c-.66.43-1.54-.05-1.54-.84Z"></path>
                      </svg>
                    </button>
                    <div className={`v-controlBar ${hideUI ? "ui-hidden" : ""}`}>
                      <div className="v-progressBar" id="play_0">
                        <div className="v-progressSeek" style={{ width: `${(state.seeking ? state.seekingLine : state.played) * 100}%` }}></div>
                        <input
                          onMouseDown={handleSeekMouseDown}
                          onChange={handleSeekChange}
                          onMouseUp={handleSeekMouseUp}
                          onPointerDown={() => handleSeekMouseDown()}
                          onPointerUp={(event) => handleSeekMouseUp(event)}
                          type="range"
                          className="v-progressInput"
                          min={0}
                          max={0.999999}
                          step="any"
                          value="0"
                          orient="horizontal"
                        />
                      </div>
                      <div className="v-controlBarContent">
                        <div className="v-playPauseButton" id="play_1" onClick={() => handleActionFile(previousFile, backRootPath)}>
                          <span className="v-previousIcon v-iconNext">
                            <svg version="1.1" viewBox="0 0 36 36">
                              <path className="ytp-svg-fill" d="m 12,12 h 2 v 12 h -2 z m 3.5,6 8.5,6 V 12 z" id="ytp-id-10"></path>
                            </svg>
                          </span>
                        </div>
                        <div
                          className="v-playPauseButton"
                          id="play_2"
                          style={compactTouch ? { display: "none" } : undefined}
                          onClick={() => handleChangeSeek(false, 120)}
                        >
                          <span className="v-nextIcon v-iconNext">
                            <svg version="1.1" viewBox="0 0 36 36">
                              <path d="M18.293 11.562v5.852l5.852-5.852v12.875l-5.852-5.852v5.852l-6.438-6.438z"></path>
                            </svg>
                          </span>
                        </div>
                        <div className="v-playPauseButton" id="play_3" onClick={() => setStateElm({ playing: !state.playing })}>
                          <span className="v-playerIcon v-iconPlay">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <path className="ytp-svg-fill" d="M 12,26 18.5,22 18.5,14 12,10 z M 18.5,22 25,18 25,18 18.5,14 z"></path>
                            </svg>
                          </span>

                          <span className="v-playerIcon v-iconPause">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <path className="ytp-svg-fill" d="M 12,26 16,26 16,10 12,10 z M 21,26 25,26 25,10 21,10 z"></path>
                            </svg>
                          </span>
                        </div>
                        <div
                          className="v-playPauseButton"
                          id="play_4"
                          style={compactTouch ? { display: "none" } : undefined}
                          onClick={() => handleChangeSeek(true, 120)}
                        >
                          <span className="v-nextIcon v-iconNext">
                            <svg version="1.1" viewBox="0 0 36 36">
                              <path d="M17.707 11.562v5.852l-5.852-5.852v12.875l5.852-5.852v5.852l6.438-6.438z"></path>
                            </svg>
                          </span>
                        </div>
                        <div className="v-playPauseButton" id="play_5" onClick={() => handleActionFile(nextFile, backRootPath)}>
                          <span className="v-nextIcon v-iconNext">
                            <svg version="1.1" viewBox="0 0 36 36">
                              <path className="ytp-svg-fill" d="M 12,24 20.5,18 12,12 V 24 z M 22,12 v 12 h 2 V 12 h -2 z" id="ytp-id-12"></path>
                            </svg>
                          </span>
                        </div>
                        <div
                          className="v-time text-white float-left h-full flex items-center !text-[length:var(--font-size)]"
                          style={compactTouch ? { display: "none" } : undefined}
                        >
                          <span className="v-currentTime">
                            <Duration seconds={state.duration * (state.seeking ? state.seekingLine : state.played)}></Duration>
                          </span>
                          &nbsp;/&nbsp;
                          <span className="v-duration">
                            <Duration seconds={state.duration}></Duration>
                          </span>
                        </div>
                        <div
                          className={`v-subtitle relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_.v-subIcon_svg]:fill-white [&_.v-subIcon_svg]:opacity-[.85] [&_.v-subIcon_svg]:h-full [&_.v-subIcon_svg]:w-full [&_.v-subIcon_svg]:[transition:opacity_.25s]`}
                          id="play_6"
                          style={hideExtraIcons ? { display: "none" } : undefined}
                          onClick={() => boxTrackHandle()}
                        >
                          <span className="v-subIcon w-full h-full">
                            <svg
                              className="ytp-subtitles-button-icon"
                              height="100%"
                              version="1.1"
                              viewBox="0 0 36 36"
                              width="100%"
                              fill-opacity={`${_.isEmpty(subtitles) ? "0.3" : "1"}`}
                            >
                              <path
                                d="M11,11 C9.9,11 9,11.9 9,13 L9,23 C9,24.1 9.9,25 11,25 L25,25 C26.1,25 27,24.1 27,23 L27,13 C27,11.9 26.1,11 25,11 L11,11 Z M11,17 L14,17 L14,19 L11,19 L11,17 L11,17 Z M20,23 L11,23 L11,21 L20,21 L20,23 L20,23 Z M25,23 L22,23 L22,21 L25,21 L25,23 L25,23 Z M25,19 L16,19 L16,17 L25,17 L25,19 L25,19 Z"
                                fill="#fff"
                                id="ytp-id-16"
                              ></path>
                            </svg>
                          </span>
                          <div
                            className={`v-subtitlesList box-border !p-[0.8em_0.8em_0.7em] bg-[rgba(250,250,252,0.98)] text-[#1b2233] !border !border-solid !border-[rgba(0,0,0,0.06)] rounded-[14px] shadow-[0_10px_30px_rgba(0,0,0,0.45)] overflow-auto max-w-[calc(100vw-20px)] max-h-[var(--menu-max-h,70vh)] absolute bottom-[calc(var(--width-bar)+var(--bar-gap,0px))] left-1/2 z-30 [transform:translateX(-50%)] [transition:opacity_0.25s_ease,visibility_0.25s_ease] ${boxTracks ? "v-active opacity-100 visible" : "opacity-0 invisible"}`}
                          >
                            <div style={{ display: "flex", alignItems: "flex-start" }}>
                              <ul className="v-subCol !px-[0.45em] !py-0 [&:first-child]:!pl-0 [&:last-child]:!pr-0 [&+&]:!ml-[0.45em] [&+&]:!pl-[0.9em] [&+&]:!border-l [&+&]:!border-solid [&+&]:!border-[#e6e8ec]">
                                <li className="flex items-center gap-[0.6em] !px-[0.3em] !pt-[0.2em] !pb-[0.6em] !text-[1em] !font-medium whitespace-nowrap pointer-events-none text-[#46557a]">
                                  <svg
                                    className="v-ccIcon"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="1.9"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    aria-hidden="true"
                                  >
                                    <rect x="2.5" y="5" width="19" height="14" rx="3" />
                                    <path d="M10.6 10.2a2.2 2.2 0 1 0 0 3.6" />
                                    <path d="M17.6 10.2a2.2 2.2 0 1 0 0 3.6" />
                                  </svg>
                                  Sub 1
                                </li>
                                <li id={`sub_0`} onClick={() => changeSubtitle(null)}>
                                  <button
                                    className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${!subtitles || !subtitles.find((s) => !!s.default) ? "v-active" : ""}`}
                                    data-language="off"
                                  >
                                    <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                    </svg>
                                    Off
                                  </button>
                                </li>
                                {subtitles &&
                                  subtitles.map((sub, index) => {
                                    return (
                                      <li id={`sub_${index + 1}`} onClick={() => changeSubtitle(sub.language)} key={index}>
                                        <button
                                          className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${sub.default ? "v-active" : ""}`}
                                          data-language="off"
                                        >
                                          <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                          </svg>
                                          {sub.lable}
                                        </button>
                                      </li>
                                    );
                                  })}
                              </ul>
                              {subtitles && subtitles.length > 1 && (
                                <ul className="v-subCol !px-[0.45em] !py-0 [&:first-child]:!pl-0 [&:last-child]:!pr-0 [&+&]:!ml-[0.45em] [&+&]:!pl-[0.9em] [&+&]:!border-l [&+&]:!border-solid [&+&]:!border-[#e6e8ec]">
                                  <li className="flex items-center gap-[0.6em] !px-[0.3em] !pt-[0.2em] !pb-[0.6em] !text-[1em] !font-medium whitespace-nowrap pointer-events-none text-[#46557a]">
                                    <svg
                                      className="v-ccIcon"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="1.9"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      aria-hidden="true"
                                    >
                                      <rect x="2.5" y="5" width="19" height="14" rx="3" />
                                      <path d="M10.6 10.2a2.2 2.2 0 1 0 0 3.6" />
                                      <path d="M17.6 10.2a2.2 2.2 0 1 0 0 3.6" />
                                    </svg>
                                    Sub 2
                                  </li>
                                  <li id="sub2_0" onClick={() => chooseSecondSub(null)}>
                                    <button
                                      className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${!secLang ? "v-active" : ""}`}
                                      data-language="off"
                                    >
                                      <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                      </svg>
                                      Off
                                    </button>
                                  </li>
                                  {subtitles
                                    .filter((sub) => sub.language !== activeSubLang)
                                    .map((sub, index) => (
                                      <li id={`sub2_${index + 1}`} onClick={() => chooseSecondSub(sub.language)} key={`s2_${index}`}>
                                        <button
                                          className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${secLang === sub.language ? "v-active" : ""}`}
                                          data-language="off"
                                        >
                                          <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                          </svg>
                                          {sub.lable}
                                        </button>
                                      </li>
                                    ))}
                                </ul>
                              )}
                            </div>
                            {/* Chỉnh độ trễ phụ đề: lùi / tới / reset (PC + điện thoại; TV dùng nút đồng hồ riêng) */}
                            {isMouse && (
                              <div
                                className="flex gap-[0.4em] !mt-[0.3em] !pt-[0.8em] !pb-0 !px-0 !border-t !border-solid !border-[#e6e8ec]"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <button
                                  type="button"
                                  className="flex-1 inline-flex items-center gap-[0.45em] appearance-none py-[0.5em] px-[0.8em] bg-[#f0f1f4] border-none rounded-full text-[#1b2233] cursor-pointer [font-family:inherit] text-[0.95em] font-medium whitespace-nowrap [transition:background-color_.2s_ease,transform_.1s_ease] hover:bg-[#e4e6ec] active:scale-[0.97] coarse:min-h-[44px] [&_svg]:w-[1.2em] [&_svg]:h-[1.2em] [&_svg]:flex-none [&_svg]:text-[#2b4a7e] justify-center"
                                  title="Phụ đề hiện sớm hơn 0.1s (phím G)"
                                  onClick={() => changeSubDelay(-SUB_DELAY_STEP)}
                                >
                                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                    <path d="M16 5.5v13a1 1 0 0 1-1.55.83l-9.6-6.5a1 1 0 0 1 0-1.66l9.6-6.5A1 1 0 0 1 16 5.5z" />
                                  </svg>
                                  −0.1s
                                </button>
                                <button
                                  type="button"
                                  className="flex-1 inline-flex items-center gap-[0.45em] appearance-none py-[0.5em] px-[0.8em] bg-[#f0f1f4] border-none rounded-full text-[#1b2233] cursor-pointer [font-family:inherit] text-[0.95em] font-medium whitespace-nowrap [transition:background-color_.2s_ease,transform_.1s_ease] hover:bg-[#e4e6ec] active:scale-[0.97] coarse:min-h-[44px] [&_svg]:w-[1.2em] [&_svg]:h-[1.2em] [&_svg]:flex-none [&_svg]:text-[#2b4a7e] justify-center"
                                  title="Phụ đề hiện trễ hơn 0.1s (phím H)"
                                  onClick={() => changeSubDelay(SUB_DELAY_STEP)}
                                >
                                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                    <path d="M8 5.5v13a1 1 0 0 0 1.55.83l9.6-6.5a1 1 0 0 0 0-1.66l-9.6-6.5A1 1 0 0 0 8 5.5z" />
                                  </svg>
                                  +0.1s
                                </button>
                                <button
                                  type="button"
                                  className="flex-1 inline-flex items-center gap-[0.45em] appearance-none py-[0.5em] px-[0.8em] bg-[#f0f1f4] border-none rounded-full text-[#1b2233] cursor-pointer [font-family:inherit] text-[0.95em] font-medium whitespace-nowrap [transition:background-color_.2s_ease,transform_.1s_ease] hover:bg-[#e4e6ec] active:scale-[0.97] coarse:min-h-[44px] [&_svg]:w-[1.2em] [&_svg]:h-[1.2em] [&_svg]:flex-none [&_svg]:text-[#2b4a7e] justify-center"
                                  title="Đặt lại độ trễ"
                                  onClick={() => changeSubDelay(null)}
                                >
                                  <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2.4"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    aria-hidden="true"
                                  >
                                    <path d="M20 12a8 8 0 1 1-2.6-5.9" />
                                    <path d="M20 4v5h-5" />
                                  </svg>
                                  Reset ({formatDelay(subDelay)})
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                        <div
                          className={`v-subtitle relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_.v-subIcon_svg]:fill-white [&_.v-subIcon_svg]:opacity-[.85] [&_.v-subIcon_svg]:h-full [&_.v-subIcon_svg]:w-full [&_.v-subIcon_svg]:[transition:opacity_.25s]`}
                          id="play_7"
                          style={hideExtraIcons ? { display: "none" } : undefined}
                          onClick={() => boxFontHandle()}
                        >
                          <span className="v-subIcon w-full h-full">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <text
                                x="18"
                                y="24"
                                textAnchor="middle"
                                fontSize="15"
                                fontWeight="600"
                                fill="#fff"
                                fontFamily="Helvetica, Arial, sans-serif"
                              >
                                Aa
                              </text>
                            </svg>
                          </span>
                          <div
                            className={`v-subtitlesList box-border !p-[0.8em_0.8em_0.7em] bg-[rgba(250,250,252,0.98)] text-[#1b2233] !border !border-solid !border-[rgba(0,0,0,0.06)] rounded-[14px] shadow-[0_10px_30px_rgba(0,0,0,0.45)] overflow-auto max-w-[calc(100vw-20px)] max-h-[var(--menu-max-h,70vh)] absolute bottom-[calc(var(--width-bar)+var(--bar-gap,0px))] left-1/2 z-30 [transform:translateX(-50%)] [transition:opacity_0.25s_ease,visibility_0.25s_ease] ${boxFont ? "v-active opacity-100 visible" : "opacity-0 invisible"}`}
                          >
                            <ul>
                              {SUB_FONT_CHOICES.map((f, fi) => (
                                <li key={f.label} className={indexFont === fi ? "fo-active" : ""} onClick={() => setSubFont(f.value)}>
                                  <button
                                    className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${subFont === f.value ? "v-active" : ""}`}
                                    style={{ fontFamily: f.value || '"Varela Round", Helvetica, Arial, sans-serif' }}
                                  >
                                    <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                    </svg>
                                    {f.label}
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div
                          className={`v-subtitle relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_.v-subIcon_svg]:fill-white [&_.v-subIcon_svg]:opacity-[.85] [&_.v-subIcon_svg]:h-full [&_.v-subIcon_svg]:w-full [&_.v-subIcon_svg]:[transition:opacity_.25s]`}
                          id="play_8"
                          style={hideExtraIcons ? { display: "none" } : undefined}
                          onClick={() => boxSpeedHandle()}
                        >
                          <span className="v-subIcon w-full h-full">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <text
                                x="18"
                                y="23"
                                textAnchor="middle"
                                fill="#fff"
                                fontWeight="700"
                                fontSize={formatSpeed(state.playbackRate).length <= 2 ? 16 : formatSpeed(state.playbackRate).length <= 4 ? 13 : 11}
                                fontFamily="inherit"
                              >
                                {formatSpeed(state.playbackRate)}
                              </text>
                            </svg>
                          </span>
                          <div
                            className={`v-subtitlesList box-border !p-[0.8em_0.8em_0.7em] bg-[rgba(250,250,252,0.98)] text-[#1b2233] !border !border-solid !border-[rgba(0,0,0,0.06)] rounded-[14px] shadow-[0_10px_30px_rgba(0,0,0,0.45)] overflow-auto max-w-[calc(100vw-20px)] max-h-[var(--menu-max-h,70vh)] absolute bottom-[calc(var(--width-bar)+var(--bar-gap,0px))] left-1/2 z-30 [transform:translateX(-50%)] [transition:opacity_0.25s_ease,visibility_0.25s_ease] ${boxSpeed ? "v-active opacity-100 visible" : "opacity-0 invisible"}`}
                          >
                            <ul>
                              {SPEED_OPTIONS.map((r, si) => (
                                <li
                                  key={`speed_${r}`}
                                  className={indexSpeed === si ? "sp-active" : ""}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    changeSpeed({ set: r });
                                  }}
                                >
                                  <button
                                    className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${state.playbackRate === r ? "v-active" : ""}`}
                                  >
                                    <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                    </svg>
                                    {r === 1 ? "Bình thường (1x)" : formatSpeed(r)}
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div
                          className={`v-subtitle relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_.v-subIcon_svg]:fill-white [&_.v-subIcon_svg]:opacity-[.85] [&_.v-subIcon_svg]:h-full [&_.v-subIcon_svg]:w-full [&_.v-subIcon_svg]:[transition:opacity_.25s]`}
                          id="play_9"
                          style={isMouse ? { display: "none" } : undefined}
                          onClick={() => boxDelayHandle()}
                        >
                          <span className="v-subIcon w-full h-full">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%" fill-opacity={`${_.isEmpty(subtitles) ? "0.3" : "1"}`}>
                              <path
                                d="M18 9a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 2a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm-1 3v5.4l4.2 2.5 1-1.6-3.2-1.9V14z"
                                fill="#fff"
                              ></path>
                            </svg>
                          </span>
                          <div
                            className={`v-subtitlesList box-border !p-[0.8em_0.8em_0.7em] bg-[rgba(250,250,252,0.98)] text-[#1b2233] !border !border-solid !border-[rgba(0,0,0,0.06)] rounded-[14px] shadow-[0_10px_30px_rgba(0,0,0,0.45)] overflow-auto max-w-[calc(100vw-20px)] max-h-[var(--menu-max-h,70vh)] absolute bottom-[calc(var(--width-bar)+var(--bar-gap,0px))] left-1/2 z-30 [transform:translateX(-50%)] [transition:opacity_0.25s_ease,visibility_0.25s_ease] ${boxDelay ? "v-active opacity-100 visible" : "opacity-0 invisible"}`}
                          >
                            <ul>
                              <li
                                id="del_0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  changeSubDelay(SUB_DELAY_STEP);
                                }}
                              >
                                <button
                                  className={`v-trackButton v-action block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px]`}
                                >
                                  Trễ hơn (+0.1s)
                                </button>
                              </li>
                              <li
                                id="del_1"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  changeSubDelay(-SUB_DELAY_STEP);
                                }}
                              >
                                <button
                                  className={`v-trackButton v-action block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px]`}
                                >
                                  Sớm hơn (-0.1s)
                                </button>
                              </li>
                              <li
                                id="del_2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  changeSubDelay(null);
                                }}
                              >
                                <button
                                  className={`v-trackButton v-action block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px]`}
                                >
                                  Đặt lại độ trễ ({formatDelay(subDelay)})
                                </button>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div
                          className={`v-subtitle relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_.v-subIcon_svg]:fill-white [&_.v-subIcon_svg]:opacity-[.85] [&_.v-subIcon_svg]:h-full [&_.v-subIcon_svg]:w-full [&_.v-subIcon_svg]:[transition:opacity_.25s]`}
                          id="play_10"
                          style={hideExtraIcons ? { display: "none" } : undefined}
                          onClick={() => boxAudioHandle()}
                        >
                          <span className="v-subIcon w-full h-full">
                            <svg
                              height="100%"
                              version="1.1"
                              viewBox="0 0 36 36"
                              width="100%"
                              fill-opacity={`${_.size(audioList) > 1 || isMouse ? "1" : "0.3"}`}
                            >
                              <path
                                d="M18,8 C12.5,8 8,12.5 8,18 L8,24 C8,25.1 8.9,26 10,26 L12,26 L12,19 L10,19 C10,14.6 13.6,11 18,11 C22.4,11 26,14.6 26,19 L24,19 L24,26 L26,26 C27.1,26 28,25.1 28,24 L28,18 C28,12.5 23.5,8 18,8 Z"
                                fill="#fff"
                              ></path>
                            </svg>
                          </span>
                          <div
                            className={`v-subtitlesList box-border !p-[0.8em_0.8em_0.7em] bg-[rgba(250,250,252,0.98)] text-[#1b2233] !border !border-solid !border-[rgba(0,0,0,0.06)] rounded-[14px] shadow-[0_10px_30px_rgba(0,0,0,0.45)] overflow-auto max-w-[calc(100vw-20px)] max-h-[var(--menu-max-h,70vh)] absolute bottom-[calc(var(--width-bar)+var(--bar-gap,0px))] left-1/2 z-30 [transform:translateX(-50%)] [transition:opacity_0.25s_ease,visibility_0.25s_ease] !left-auto !right-0 ![transform:none] v-popRight ${boxAudio ? "v-active opacity-100 visible" : "opacity-0 invisible"}`}
                          >
                            <ul>
                              {audioList.map((audio, index) => (
                                <li id={`aud_${index}`} onClick={() => changeAudio(index)} key={index}>
                                  <button
                                    className={`v-trackButton block w-full appearance-none border-none outline-none cursor-pointer [font-family:inherit] text-left relative whitespace-nowrap bg-[#f3f4f6] text-[#1b2233] rounded-[10px] py-[0.6em] pl-[1em] pr-[2.8em] [transition:background-color_0.25s_ease] hover:bg-[#eceef3] [&.v-active]:!bg-[#e6eeff] [&.v-active]:!text-[#0f1a33] [&.v-active]:!font-semibold [&.v-action]:pr-[1.1em] coarse:min-h-[44px] coarse:!p-[10px_44px_10px_16px] [&.v-action]:coarse:!pr-[16px] ${audio.enabled ? "v-active" : ""}`}
                                  >
                                    <svg viewBox="0 0 18 14" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M5.6 10.6 1.4 6.4 0 7.8l5.6 5.6 12-12L16.2 0z"></path>
                                    </svg>
                                    {audio.label}
                                  </button>
                                </li>
                              ))}
                            </ul>
                            {isMouse && (
                              <div
                                className="flex gap-[0.4em] !mt-[0.3em] !pt-[0.8em] !pb-0 !px-0 !border-t !border-solid !border-[#e6e8ec] v-muteBar"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <button
                                  type="button"
                                  className={`flex-1 inline-flex items-center gap-[0.45em] appearance-none py-[0.5em] px-[0.8em] bg-[#f0f1f4] border-none rounded-full text-[#1b2233] cursor-pointer [font-family:inherit] text-[0.95em] font-medium whitespace-nowrap [transition:background-color_.2s_ease,transform_.1s_ease] hover:bg-[#e4e6ec] active:scale-[0.97] coarse:min-h-[44px] [&_svg]:w-[1.2em] [&_svg]:h-[1.2em] [&_svg]:flex-none [&_svg]:text-[#2b4a7e] justify-start !pl-[1em] ${state.muted ? "!bg-[#e6eeff] !text-[#0f1a33] !font-semibold [&_svg]:!text-[#1f5eff]" : ""}`}
                                  title="Bật / tắt âm (phím M)"
                                  aria-pressed={state.muted}
                                  onClick={() => {
                                    setStateElm({ muted: !state.muted });
                                    handleAutoHide();
                                  }}
                                >
                                  {state.muted ? (
                                    <svg viewBox="0 0 36 36" fill="currentColor" aria-hidden="true">
                                      <path d="m 21.48,17.98 c 0,-1.77 -1.02,-3.29 -2.5,-4.03 v 2.21 l 2.45,2.45 c .03,-0.2 .05,-0.41 .05,-0.63 z m 2.5,0 c 0,.94 -0.2,1.82 -0.54,2.64 l 1.51,1.51 c .66,-1.24 1.03,-2.65 1.03,-4.15 0,-4.28 -2.99,-7.86 -7,-8.76 v 2.05 c 2.89,.86 5,3.54 5,6.71 z M 9.25,8.98 l -1.27,1.26 4.72,4.73 H 7.98 v 6 H 11.98 l 5,5 v -6.73 l 4.25,4.25 c -0.67,.52 -1.42,.93 -2.25,1.18 v 2.06 c 1.38,-0.31 2.63,-0.95 3.69,-1.81 l 2.04,2.05 1.27,-1.27 -9,-9 -7.72,-7.72 z m 7.72,.99 -2.09,2.08 2.09,2.09 V 9.98 z" />
                                    </svg>
                                  ) : (
                                    <svg viewBox="0 0 36 36" fill="currentColor" aria-hidden="true">
                                      <path d="M8,21 L12,21 L17,26 L17,10 L12,15 L8,15 L8,21 Z M19,14 L19,22 C20.48,21.32 21.5,19.77 21.5,18 C21.5,16.26 20.48,14.74 19,14 ZM19,11.29 C21.89,12.15 24,14.83 24,18 C24,21.17 21.89,23.85 19,24.71 L19,26.77 C23.01,25.86 26,22.28 26,18 C26,13.72 23.01,10.14 19,9.23 L19,11.29 Z" />
                                    </svg>
                                  )}
                                  {state.muted ? "Đang tắt âm - bấm để bật" : "Tắt âm"}
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                        <div
                          className={`v-volume relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_svg]:fill-white [&_svg]:opacity-[.85] [&_svg]:h-full [&_svg]:w-full [&_svg]:[transition:opacity_.25s] ${state.muted ? "v-muted" : ""}`}
                          id="play_11"
                          style={isMouse ? { display: "none" } : undefined}
                          onClick={() => setStateElm({ muted: !state.muted })}
                        >
                          <span className="v-playerIcon v-iconVolumeHigh">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <path
                                className="ytp-svg-fill ytp-svg-volume-animation-speaker"
                                clip-path="url(#ytp-svg-volume-animation-mask)"
                                d="M8,21 L12,21 L17,26 L17,10 L12,15 L8,15 L8,21 Z M19,14 L19,22 C20.48,21.32 21.5,19.77 21.5,18 C21.5,16.26 20.48,14.74 19,14 ZM19,11.29 C21.89,12.15 24,14.83 24,18 C24,21.17 21.89,23.85 19,24.71 L19,26.77 C23.01,25.86 26,22.28 26,18 C26,13.72 23.01,10.14 19,9.23 L19,11.29 Z"
                                fill="#fff"
                              ></path>
                            </svg>
                          </span>
                          <span className="v-playerIcon v-iconVolumeMute">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <path
                                className="ytp-svg-fill"
                                d="m 21.48,17.98 c 0,-1.77 -1.02,-3.29 -2.5,-4.03 v 2.21 l 2.45,2.45 c .03,-0.2 .05,-0.41 .05,-0.63 z m 2.5,0 c 0,.94 -0.2,1.82 -0.54,2.64 l 1.51,1.51 c .66,-1.24 1.03,-2.65 1.03,-4.15 0,-4.28 -2.99,-7.86 -7,-8.76 v 2.05 c 2.89,.86 5,3.54 5,6.71 z M 9.25,8.98 l -1.27,1.26 4.72,4.73 H 7.98 v 6 H 11.98 l 5,5 v -6.73 l 4.25,4.25 c -0.67,.52 -1.42,.93 -2.25,1.18 v 2.06 c 1.38,-0.31 2.63,-0.95 3.69,-1.81 l 2.04,2.05 1.27,-1.27 -9,-9 -7.72,-7.72 z m 7.72,.99 -2.09,2.08 2.09,2.09 V 9.98 z"
                                id="ytp-id-229"
                              ></path>
                            </svg>
                          </span>
                        </div>
                        <div
                          className={`v-fullscreen relative inline-block w-[var(--width-bar)] h-full cursor-pointer [&_svg]:fill-white [&_svg]:opacity-[.85] [&_svg]:h-full [&_svg]:w-full [&_svg]:[transition:opacity_.25s] ${isFullSreen ? "v-exit" : ""}`}
                          id="play_12"
                          onClick={() => handleFullSreen(!isFullSreen)}
                        >
                          <span className="v-playerIcon v-iconFullscreen">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <g className="ytp-fullscreen-button-corner-0">
                                <path className="ytp-svg-fill" d="m 10,16 2,0 0,-4 4,0 0,-2 L 10,10 l 0,6 0,0 z" id="ytp-id-207"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-1">
                                <path className="ytp-svg-fill" d="m 20,10 0,2 4,0 0,4 2,0 L 26,10 l -6,0 0,0 z" id="ytp-id-208"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-2">
                                <path className="ytp-svg-fill" d="m 24,24 -4,0 0,2 L 26,26 l 0,-6 -2,0 0,4 0,0 z" id="ytp-id-209"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-3">
                                <path className="ytp-svg-fill" d="M 12,20 10,20 10,26 l 6,0 0,-2 -4,0 0,-4 0,0 z" id="ytp-id-210"></path>
                              </g>
                            </svg>
                          </span>
                          <span className="v-playerIcon v-iconShrink">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                              <g className="ytp-fullscreen-button-corner-2">
                                <path className="ytp-svg-fill" d="m 14,14 -4,0 0,2 6,0 0,-6 -2,0 0,4 0,0 z" id="ytp-id-245"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-3">
                                <path className="ytp-svg-fill" d="m 22,14 0,-4 -2,0 0,6 6,0 0,-2 -4,0 0,0 z" id="ytp-id-246"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-0">
                                <path className="ytp-svg-fill" d="m 20,26 2,0 0,-4 4,0 0,-2 -6,0 0,6 0,0 z" id="ytp-id-247"></path>
                              </g>
                              <g className="ytp-fullscreen-button-corner-1">
                                <path className="ytp-svg-fill" d="m 10,22 4,0 0,4 2,0 0,-6 -6,0 0,2 0,0 z" id="ytp-id-248"></path>
                              </g>
                            </svg>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {(isMouse || audioOnly) && !_.isEmpty(subtitles) && (!fsSide || sideOpen) && !cuePanelHidden && (
                  <div
                    id="cue_panel"
                    {...hoverSavedHandlers(openTranslate)}
                    {...(audioOnly ? wordSelectHandlers({ onWord: openTranslate }) : {})}
                    onWheel={() => (userScrollRef.current = Date.now())}
                    onMouseDown={(e) => {
                      userScrollRef.current = Date.now();
                      // Chỉ nghe: bấm vào chữ thì tạm dừng để bôi đen / đọc nghĩa kịp (giống chữ sub trên video)
                      if (audioOnly && state.playing && e.target && e.target.closest && e.target.closest("[data-sub-seg]"))
                        setStateElm({ playing: false });
                    }}
                    onTouchStart={(e) => {
                      userScrollRef.current = Date.now();
                      if (touch && audioOnly) swipeCue.onTouchStart(e);
                    }}
                    onTouchMove={(e) => {
                      if (touch && audioOnly) swipeCue.onTouchMove(e);
                    }}
                    onTouchEnd={() => {
                      if (touch && audioOnly) swipeCue.onTouchEnd();
                    }}
                    style={{
                      touchAction: touch && audioOnly ? "pan-y" : undefined, // cuộn dọc như thường, quẹt ngang để chọn chữ
                      userSelect: audioOnly ? "text" : undefined,
                      WebkitUserSelect: audioOnly ? "text" : undefined,
                      width: fsSide ? "max(200px, 25vw)" : layoutStacked ? "100%" : "min(360px, 40vw)",
                      flexShrink: 0,
                      height: fsSide ? "100%" : audioOnly ? "max(240px, calc(100vh - 130px))" : stacked ? "50vh" : "80vh", // chỉ nghe: khung sub chiếm gần hết phần còn lại của màn hình
                      maxWidth: audioOnly ? "900px" : undefined,
                      alignSelf: audioOnly ? "center" : undefined,
                      overflowY: "auto",
                      position: "relative",
                      background: "#141414",
                      color: "#ddd",
                      textAlign: "left",
                      cursor: "default",
                      fontSize: fsSide ? "13px" : audioOnly ? "17px" : "15px", // toàn màn hình: khung hẹp nên chữ nhỏ hơn
                      lineHeight: 1.4,
                      borderRadius: fsSide ? 0 : "6px"
                    }}
                  >
                    {!activeSubLang ? (
                      <div style={{ padding: "16px", color: "#888" }}>Phụ đề đang tắt. Bật phụ đề ở nút CC để xem danh sách.</div>
                    ) : _.isEmpty(cueList) ? (
                      <div style={{ padding: "16px", color: "#888" }}>Đang tải phụ đề...</div>
                    ) : (
                      cueList.map((cue, i) => (
                        <React.Fragment key={i}>
                          {gap && gap.next === i && (
                            <div
                              title="Còn bao lâu đến sub tiếp theo"
                              style={{ height: 3, margin: "6px 10px 0", background: "#333", borderRadius: 2, overflow: "hidden" }}
                            >
                              <div style={{ height: "100%", width: `${gap.p * 100}%`, background: "#ffd700", transition: "width .25s linear" }} />
                            </div>
                          )}
                          <div
                            id={`cue_${i}`}
                            onClick={audioOnly ? undefined : () => seekToCue(cue)} // chỉ nghe: bấm vào chữ để tô đen / dịch, đi tới câu bằng nút riêng
                            style={{
                              padding: "6px 10px",
                              cursor: audioOnly ? "default" : "pointer",
                              display: "flex",
                              alignItems: "flex-start",
                              gap: "8px",
                              borderLeft: `3px solid ${i === cueIndex ? "#ffd700" : "transparent"}`,
                              background: i === cueIndex ? "#2c2c2c" : "transparent",
                              color: i === cueIndex ? "#fff" : "#aaa"
                            }}
                          >
                            <div style={{ flex: 1 }}>
                              <span style={{ color: "#777", fontSize: fsSide ? "10px" : "12px", marginRight: "8px" }}>{formatClock(cue.start)}</span>
                              <span data-sub-seg="1" style={audioOnly ? { cursor: "text", userSelect: "text", WebkitUserSelect: "text" } : undefined}>
                                {highlightSaved(cue.text, savedMatcher, "c" + i)}
                              </span>
                            </div>
                            {audioOnly && (
                              <button
                                type="button"
                                title="Phát video từ câu này"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  seekToCue(cue);
                                }}
                                style={{
                                  flexShrink: 0,
                                  width: fsSide ? (touch ? "28px" : "22px") : touch ? "36px" : "28px",
                                  height: fsSide ? (touch ? "28px" : "22px") : touch ? "36px" : "28px",
                                  borderRadius: "50%",
                                  border: "1px solid #5aa564",
                                  background: "transparent",
                                  color: "#7fcf8a",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  lineHeight: 1,
                                  fontSize: "13px",
                                  padding: 0,
                                  cursor: "pointer"
                                }}
                              >
                                ▶
                              </button>
                            )}
                            <button
                              type="button"
                              title="Lặp lại câu này"
                              aria-pressed={i === loopIndex}
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleLoop(i);
                              }}
                              style={{
                                flexShrink: 0,
                                width: fsSide ? (touch ? "28px" : "22px") : touch ? "36px" : "28px",
                                height: fsSide ? (touch ? "28px" : "22px") : touch ? "36px" : "28px",
                                borderRadius: "50%",
                                border: "1px solid " + (i === loopIndex ? "#ffd700" : "#444"),
                                background: i === loopIndex ? "#ffd700" : "transparent",
                                color: i === loopIndex ? "#000" : "#888",
                                fontSize: "14px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                lineHeight: 1,
                                padding: 0,
                                cursor: "pointer"
                              }}
                            >
                              ⟲
                            </button>
                          </div>
                        </React.Fragment>
                      ))
                    )}
                  </div>
                )}
                {audioOnly && trWord && (
                  <TranslatePopup
                    key={trWord.id}
                    apiBase={`http://${hostname}:8081`}
                    text={trWord.text}
                    anchor={trWord.anchor}
                    hoverId={trWord.hoverId}
                    onClose={() => setTrWord(null)}
                  />
                )}
              </div>
            )}
          </div>
        </header>
      </div>
    </>
  );
};

export default Home;
