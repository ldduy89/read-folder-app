
import "./App.css";
// importing components from react-router-dom package
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
// import Home component
import Home from "./home";
import Read from "./read";
import TranslateWords from "./translateWords";
import TranslateSettings from "./translateSettings";

function App() {
  return (
    <>
      {/* This is the alias of BrowserRouter i.e. Router */}
      <Router>
        <Switch>
          {/* This route is for home component 
          with exact path "/", in component props 
          we passes the imported component*/}
          <Route exact path="/read/*" component={Read} />
          <Route exact path="/translate-words" component={TranslateWords} />
          <Route exact path="/translate-settings" component={TranslateSettings} />
          <Route exact path="/*" component={Home} />

          

          {/* If any route mismatches the upper 
          route endpoints then, redirect triggers 
          and redirects app to home component with to="/" */}
          <Redirect to="/" />
        </Switch>
      </Router>
    </>
  );
}

export default App;